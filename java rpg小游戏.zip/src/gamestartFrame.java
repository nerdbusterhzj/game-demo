import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.util.Random;
import javax.swing.JOptionPane;

import javax.swing.*;

public class gamestartFrame extends JFrame implements gameConfig{
	static int gamestartflag=0;
	public gamestartFrame(){
		init();
	}
	public void init() {
		this.setTitle(title);
		this.setSize(frameX, frameY);
		this.getContentPane().setBackground(Color.BLACK);
		this.setLayout(new FlowLayout());
		this.setDefaultCloseOperation(HIDE_ON_CLOSE);
		if(gamestartflag==0) this.setVisible(true);
		
		if(gamestartflag==0)
		{
			JLabel ti =new JLabel("DQC PROJECT by nerdhzj");
			ti.setBounds(100, 100, 100, 100);
			ti.setForeground(Color.WHITE);
			ti.setFont(new Font("", Font.BOLD, 36));
			this.add(ti);
			
			JButton gamestart=new JButton("��ʼ��Ϸ");
			gamestart.setFont(new Font("����", Font.PLAIN, 15));
			gamestart.setForeground(Color.WHITE);
			gamestart.setContentAreaFilled(false);
			gamestart.setBorderPainted(false);
			gamestart.setBounds(180, 180, 100, 50);
			gamestart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					mainFrame mf=new mainFrame();
					gamestartflag=1;
					gamestart();
				}
			});;
			this.add(gamestart);
			
			JButton gamecon=new JButton("������Ϸ");
			gamecon.setFont(new Font("����", Font.PLAIN, 15));
			gamecon.setForeground(Color.WHITE);
			gamecon.setContentAreaFilled(false);
			gamecon.setBorderPainted(false);
			gamecon.setBounds(180, 230, 100, 50);
			gamecon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					mainFrame mf=new mainFrame();
					try {
						MenuPanel.load();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					gamestartflag=1;
					gamestart();
				}
			});;
			this.add(gamecon);
			
			JButton inf=new JButton("����˵��");
			inf.setFont(new Font("����", Font.PLAIN, 15));
			inf.setForeground(Color.WHITE);
			inf.setContentAreaFilled(false);
			inf.setBorderPainted(false);
			inf.setBounds(180, 280, 100, 50);
			inf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					gameinf();
				}
			});;
			this.add(inf);
			
			JButton th=new JButton("��л");
			th.setFont(new Font("����", Font.PLAIN, 15));
			th.setForeground(Color.WHITE);
			th.setContentAreaFilled(false);
			th.setBorderPainted(false);
			th.setBounds(180, 330, 100, 50);
			th.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					gameth();
				}
			});;
			this.add(th);
		}
	}
	public void gamestart() {
		this.setVisible(false);
	}
	public void gameinf() {
		JOptionPane.showMessageDialog(null,"WASD�ƶ���G�Ի�/������T�л���ͼ��I�򿪱����˵�","���Ǹ�RPG��Ϸ��",JOptionPane.INFORMATION_MESSAGE);
	}
	public void gameth() {
		JOptionPane.showMessageDialog(null,"��֯�İ��Ҳ�bug����ӵ�ͬ־�ǣ�DQ֮��ܥ���۶����ҵ�����","��л",JOptionPane.INFORMATION_MESSAGE);
	}
}