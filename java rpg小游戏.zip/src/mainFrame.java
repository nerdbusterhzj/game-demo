import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Random;

import javax.swing.*;
public class mainFrame extends JFrame implements gameConfig{
	//��Ϸ���
	static int mapflag=2;
	static int npcnum;
	static int tpnum;
	static int roomnum;
	static int randnum=0;
	static int tag=1;//1Ϊ�ƶ���2Ϊ�Ի�, 3Ϊ�˵���4Ϊս��
    JPanel panel;
	JPanel tpanel;
	JPanel mpanel;
	JPanel bpanel;
	public mainFrame() {
		init();	
	}
	
	public void init(){
		this.setTitle(title);
		this.setSize(frameX, frameY);
		this.setLayout(new FlowLayout());
		this.setDefaultCloseOperation(3);
		this.setVisible(true);
	
		//������Ϸ���
		panel = setpanel();
		tpanel = settpanel();
		mpanel = setmpanel();
		bpanel = setbpanel();
		
		this.add(bpanel);
		this.add(mpanel);
		this.add(tpanel);
		this.add(panel);
		
		//��װ���̼�����
		PanelListenner plis = new PanelListenner();
		this.addKeyListener(plis);
		
		//���������ƶ��߳�
		Player player = new Player();
		player.start();
		
		//����ˢ������߳�
		UpdateThread ut = new UpdateThread(panel,tpanel,mpanel,bpanel);
		ut.start();
		System.out.println(MenuPanel.menuflag);
		//��ʼ���˵�
		tag=3;
		System.out.println("i");
		MenuPanel.menuflag=0;
		System.out.println(MenuPanel.menuflag);
		mpanel.setBounds(40, 50, 400, 330);
		MenuPanel.menuflag=-1;
		//��ʼ��ս�����
		tag=4;
		BattelPanel.turn=0;
		BattelPanel.damage=0;
		Random rand=new Random();
		BattelPanel.enemytype=rand.nextInt(2)+1;
		BattelPanel.battelflag=0;
		bpanel.setBounds(40, 50, 400, 400);
		BattelPanel.battelflag=-1;
		}
		
	public JPanel setpanel(){
		JPanel panel = new MyPanel();
		panel.setPreferredSize(new Dimension(panelX, panelY));
		panel.setLayout(null);
		panel.setBackground(Color.black);
		
		return panel;
	}
	public JPanel settpanel(){
		JPanel tpanel = new TalkPanel();
		return tpanel;
	}
	public JPanel setmpanel() {
		JPanel mpanel=new MenuPanel();
		return mpanel;
	}
	public JPanel setbpanel() {
		JPanel bpanel=new BattelPanel();
		return bpanel;
	}
	///void rest() {
		//requestFocus(true);
	//}
	
	class PanelListenner extends KeyAdapter{
		//����������
		public void keyPressed(KeyEvent e){
			int code = e.getKeyCode();
			if(tag==1){
			switch (code) {
			//case KeyEvent.VK_1:
				//ReadMapFile.readfile("map1.map");
				//mapflag=1;
				//Player.movepoint=0;
				//break;
			//case KeyEvent.VK_2:
				//ReadMapFile.readfile("map2.map");
				//mapflag=2;
				//Player.movepoint=0;
				//break;
			//case KeyEvent.VK_3:
				//ReadMapFile.readfile("map3.map");
				//mapflag=3;
				//Player.movepoint=0;
				//break;
			//case KeyEvent.VK_4:
				//ReadMapFile.readfile("map4.map");
				//mapflag=4;
				//Player.movepoint=0;
				//Player.x=525;
				//Player.y=1625;
				//Player.mx=5000;
				//Player.my=5000;
				//break;
			case KeyEvent.VK_I:
				tag=3;
				System.out.println("i");
				MenuPanel.menuflag=0;
				System.out.println(MenuPanel.menuflag);
				mpanel.setBounds(40, 50, 400, 330);
				break;
			case KeyEvent.VK_W:
				Player.up = true;
				Player.towards=1;
				System.out.println(Player.movepoint);
				if(Player.movepoint>=18&&(mapflag==1||mapflag==4)) {
					System.out.println("battle");
					tag=4;
					BattelPanel.turn=0;
					BattelPanel.damage=0;
					Random rand=new Random();
					randnum=rand.nextInt(100)+1;
					System.out.println(randnum);
					if(mapflag==1)
					{
						if(randnum>=60) BattelPanel.enemytype=2;
						else if(randnum<60)	BattelPanel.enemytype=1;
					}
					else if(mapflag==4)
					{
						if(randnum>50&&randnum<90) BattelPanel.enemytype=3;
						else if(randnum<=50)	BattelPanel.enemytype=2;
						else if(randnum>=90)	BattelPanel.enemytype=4;
					}
					BattelPanel.battelflag=0;
					bpanel.setBounds(40, 50, 400, 400);
					Player.movepoint=0;
				}
				break;
			case KeyEvent.VK_S:
				Player.down = true;
				Player.towards=2;
				System.out.println(Player.movepoint);
				if(Player.movepoint>=18&&(mapflag==1||mapflag==4)) {
					System.out.println("battle");
					tag=4;
					BattelPanel.turn=0;
					BattelPanel.damage=0;
					Random rand=new Random();
					randnum=rand.nextInt(100)+1;
					System.out.println(randnum);
					if(mapflag==1)
					{
						if(randnum>=60) BattelPanel.enemytype=2;
						else if(randnum<60)	BattelPanel.enemytype=1;
					}
					else if(mapflag==4)
					{
						if(randnum>50&&randnum<890) BattelPanel.enemytype=3;
						else if(randnum<=50)	BattelPanel.enemytype=2;
						else if(randnum>=90)	BattelPanel.enemytype=4;
					}
					BattelPanel.battelflag=0;
					bpanel.setBounds(40, 50, 400, 400);
					Player.movepoint=0;
				}
				break;
			case KeyEvent.VK_A:
				Player.left = true;
				Player.towards=3;
				System.out.println(Player.movepoint);
				if(Player.movepoint>=18&&(mapflag==1||mapflag==4)) {
					System.out.println("battle");
					tag=4;
					BattelPanel.turn=0;
					BattelPanel.damage=0;
					Random rand=new Random();
					randnum=rand.nextInt(100)+1;
					System.out.println(randnum);
					if(mapflag==1)
					{
						if(randnum>=60) BattelPanel.enemytype=2;
						else if(randnum<60)	BattelPanel.enemytype=1;
					}
					else if(mapflag==4)
					{
						if(randnum>50&&randnum<90) BattelPanel.enemytype=3;
						else if(randnum<=50)	BattelPanel.enemytype=2;
						else if(randnum>=90)	BattelPanel.enemytype=4;
					}
					BattelPanel.battelflag=0;
					bpanel.setBounds(40, 50, 400, 400);
					Player.movepoint=0;
				}
				break;
			case KeyEvent.VK_D:
				Player.right = true;
				Player.towards=4;
				System.out.println(Player.movepoint);
				if(Player.movepoint>=18&&(mapflag==1&&mapflag==4)) {
					System.out.println("battle");
					tag=4;
					BattelPanel.turn=0;
					BattelPanel.damage=0;
					Random rand=new Random();
					randnum=rand.nextInt(100)+1;
					System.out.println(randnum);
					if(mapflag==1)
					{
						if(randnum>=60) BattelPanel.enemytype=2;
						else if(randnum<60)	BattelPanel.enemytype=1;
					}
					else if(mapflag==4)
					{
						if(randnum>50&&randnum<90) BattelPanel.enemytype=3;
						else if(randnum<=50)	BattelPanel.enemytype=2;
						else if(randnum>=90)	BattelPanel.enemytype=4;
					}
					BattelPanel.battelflag=0;
					bpanel.setBounds(40, 50, 400, 400);
					Player.movepoint=0;
				}
				break;
			case KeyEvent.VK_G://�����˶Ի���
				//System.out.println("g");
				if(Player.towards==1){//��ɫ������
					npcnum = ReadMapFile.map3[Player.y/elesize-1][Player.x/elesize];
					if(npcnum!=0){//�Ϸ���npc
						TalkPanel.shopflag=0;
						TalkPanel.timeconut=0;
						tag = 2;
						System.out.println("starttalk");
						tpanel.setBounds(0, 300, 2000, 350);
						//tpanel.repaint();
					}
				}
				else if(Player.towards==2){
					npcnum= ReadMapFile.map3[Player.y/elesize+1][Player.x/elesize];
					if(npcnum==609||npcnum==605||npcnum==607)
					{
						TalkPanel.shopflag=0;
						TalkPanel.timeconut=0;
						tag=2;
						tpanel.setBounds(0, 300, 2000, 350);
					}
				}
				else if(Player.towards==3){
					npcnum= ReadMapFile.map2[Player.y/elesize][Player.x/elesize-1];
					if(npcnum==609||npcnum==605||npcnum==607)
					{
						TalkPanel.shopflag=0;
						TalkPanel.timeconut=0;
						tag=2;
						tpanel.setBounds(0, 300, 2000, 350);
					}
				}
				else if(Player.towards==4){
					npcnum= ReadMapFile.map3[Player.y/elesize][Player.x/elesize+1];
					if(npcnum==609||npcnum==605)
					{
						TalkPanel.shopflag=0;
						TalkPanel.timeconut=0;
						tag=2;
						tpanel.setBounds(0, 300, 2000, 350);
					}
				}
					
				break;
			case KeyEvent.VK_T://�л���ͼ
				npcnum=ReadMapFile.map3[Player.y/elesize+1][Player.x/elesize];
				tpnum=ReadMapFile.map3[Player.y/elesize-1][Player.x/elesize];
				roomnum=ReadMapFile.map3[Player.y/elesize+1][Player.x/elesize];
				if(npcnum==998)
				{
					if(mapflag==3)
					{
						Player.x=575;
						Player.y=475;
						Player.mx=5000;
						Player.my=5000;
					}
					else if(mapflag==2)
					{
						Player.x=675;
						Player.y=1475;
						Player.mx=5000;
						Player.my=5000;
					}
					else if(mapflag==4)
					{
						Player.x=1225;
						Player.y=475;
						Player.mx=5000;
						Player.my=5000;
					}
					ReadMapFile.readfile("map1.map");
					mapflag=1;
					Player.movepoint=0;
				}
				else if(tpnum==115)
				{
					Player.x=725;
					Player.y=975;
					Player.mx=1000;
					Player.my=1000;
					ReadMapFile.readfile("map3.map");
					mapflag=3;
					Player.movepoint=0;
				}
				else if(tpnum==114)
				{
					ReadMapFile.readfile("map4.map");
					mapflag=4;
					Player.movepoint=0;
					Player.x=525;
					Player.y=1625;
					Player.mx=5000;
					Player.my=5000;
					break;
				}
				else if(roomnum==113)//����
				{
					Player.x=725;
					Player.y=875;
					Player.mx=1000;
					Player.my=1000;
					ReadMapFile.readfile("map2.map");
					mapflag=2;
					Player.movepoint=0;
				}
				break;
			default:
				break;
			}
		}
			else if(tag==2){//�رնԻ���
				if(code==KeyEvent.VK_G){
					tag=1;
					TalkPanel.shopflag=0;
					TalkPanel.timeconut=0;
					tpanel.setBounds(28, 500, 0, 0);
					TalkPanel.talk1="";
					TalkPanel.talk2="";
					TalkPanel.talk3="";
					TalkPanel.talk4="";
					System.out.println("t");
				}	
				}
			else if(tag==3) {//�رղ˵�
				if(code==KeyEvent.VK_I)
				{
					tag=1;
					mpanel.setBounds(28, 500, 0, 0);
					System.out.println(MenuPanel.menuflag);
					System.out.println("m");
				}
			}
		}
		//�������ͷ�
		public void keyReleased(KeyEvent e){
			int code = e.getKeyCode();
			switch (code) {
			case KeyEvent.VK_W:
				Player.up = false;
				Player.up1 = 0;
				break;
			case KeyEvent.VK_S:
				Player.down = false;
				Player.down1 = 0;
				break;
			case KeyEvent.VK_A:
				Player.left = false;
				Player.left1 = 0;
				break;
			case KeyEvent.VK_D:
				Player.right = false;
				Player.right1 = 0;
				break;
			default:
				break;
			}
		}
	}
	class MyPanel extends JPanel{
		@Override
		public void paint(Graphics g) {
			super.paint(g);
			//�ҵ���ɫ�Աߵ��زģ��������Ҹ�5��
			for(int i=Player.getI()-6;i<=Player.getI()+6;i++){
				for(int j=Player.getJ()-6;j<=Player.getJ()+6;j++){
					if(i>=0&&j>=0&&i<ReadMapFile.map1.length&&j<ReadMapFile.map1[0].length) {
						//����һ��Ԫ��
						ImageIcon icon1 = GetMap.int2icon(ReadMapFile.map1[i][j]);
						g.drawImage(icon1.getImage(), (Player.px-elesize/2)+((j-Player.getJ())*elesize)-(Player.mx%elesize), (Player.py-elesize/2)+((i-Player.getI())*elesize)-(Player.my%elesize), elesize, elesize, null);
						//�ڶ���
						if((ReadMapFile.map1[i][j]!=0&&ReadMapFile.map2[i][j]!=0)||ReadMapFile.map1[i][j]==0&&ReadMapFile.map2[i][j]!=0) {
							ImageIcon icon2 = GetMap.int2icon(ReadMapFile.map2[i][j]);
							g.drawImage(icon2.getImage(), (Player.px-elesize/2)+((j-Player.getJ())*elesize)-(Player.mx%elesize), (Player.py-elesize/2)+((i-Player.getI())*elesize)-(Player.my%elesize), elesize, elesize, null);
						}
						//������
						if(ReadMapFile.map3[i][j]!=0)
						{
							ImageIcon icon3 = GetMap.int2icon(ReadMapFile.map3[i][j]);
							g.drawImage(icon3.getImage(), (Player.px-elesize/2)+((j-Player.getJ())*elesize)-(Player.mx%elesize), (Player.py-elesize/2)+((i-Player.getI())*elesize)-(Player.my%elesize), elesize, elesize, null);
							}
						}
				}
			}
			Player.draw(g);
			ImageIcon shadow = new ImageIcon("��ͷ��Ӱ.png");
			//ImageIcon shadow1 =new ImageIcon("��ͷ��Ӱ1.png");
			if(mapflag==4||mapflag==1) g.drawImage(shadow.getImage(), 0, 0, 500, 500, null);
			//else if(mapflag==1) g.drawImage(shadow1.getImage(), 0, 0, 500, 500, null);
			//System.out.println(Player.x+" "+Player.y);
			//System.out.println(ReadMapFile.map3[Player.y/elesize-1][Player.x/elesize]);
			//System.out.println(ReadMapFile.map3[Player.y/elesize+1][Player.x/elesize]);
			//System.out.println(ReadMapFile.map3[Player.y/elesize][Player.x/elesize-1]);
			//System.out.println(Player.mx+" "+Player.my);
			if(BattelPanel.gameoverflag==1)
			{
				tag=2;
				tpanel.setBounds(0, 0, 500, 500);
			}
		}
	}
		public static void main(String[] args) {
			//���ȴӵ�ͼ�ļ��ж����ͼ����
			ReadMapFile.readfile("map2.map");
			gamestartFrame gf=new gamestartFrame();
			//�ö����ĵ�ͼ���鴴����Ϸ���壬��ʼ��Ϸ
			//mainFrame mf = new mainFrame();
			//for(int i=0;i<40;i++)
			//{
				//for(int j=0;j<40;j++)
				//{//System.out.println(ReadMapFile.map1[i][j]);
				//System.out.println(ReadMapFile.map2[i][j]);
				//System.out.println(ReadMapFile.map3[i][j]);
				//}		
			//}
		}
	}