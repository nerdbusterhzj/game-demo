import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;


public class MenuPanel extends JPanel implements gameConfig{
	static int menuflag=0;
	public MenuPanel()
	{
		init();
	}
	public void init()
	{
		this.setBounds(40, 50, 0, 0);
		this.setLayout(null);
		//this.setOpaque(false);//�������͸��
	}
	
	
	@Override
	public void paint(Graphics g)
	{
		super.paint(g);
		//System.out.println("drawmenu");
		this.setBackground(Color.BLACK);
		this.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		//g.drawLine(90, 30, 370, 30);
		g.setColor(Color.white);
		g.drawRect(90, 30, 300, 220);
		
		JButton state=new JButton("״̬");
		state.setFont(new Font("����", Font.PLAIN, 16));
		state.setForeground(Color.WHITE);
		state.setContentAreaFilled(false);
		state.setBorderPainted(false);
		state.setBounds(0, 0, 100, 100);
		state.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menuflag=1;
				removeAll();
			}});
		this.add(state);
		
		
		JButton item=new JButton("����");
		item.setFont(new Font("����", Font.PLAIN, 16));
		item.setForeground(Color.WHITE);
		item.setContentAreaFilled(false);
		item.setBorderPainted(false);
		item.setBounds(0, 75, 100, 100);
		item.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menuflag=2;
				removeAll();
				System.out.println(menuflag);
			}});
		this.add(item);
		
		JButton system=new JButton("ϵͳ");
		system.setFont(new Font("����", Font.PLAIN, 16));
		system.setForeground(Color.WHITE);
		system.setContentAreaFilled(false);
		system.setBorderPainted(false);
		system.setBounds(0, 225, 100, 100);
		system.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menuflag=4;
				removeAll();
				System.out.println(menuflag);
			}});
		this.add(system);
		
		JButton skill=new JButton("����");
		skill.setFont(new Font("����", Font.PLAIN, 16));
		skill.setForeground(Color.WHITE);
		skill.setContentAreaFilled(false);
		skill.setBorderPainted(false);
		skill.setBounds(0, 150, 100, 100);
		skill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menuflag=3;
				removeAll();
				System.out.println(menuflag);
			}});
		
		this.add(skill);
			
		JButton back=new JButton("������Ϸ");
		back.setFont(new Font("����", Font.PLAIN, 16));
		back.setForeground(Color.WHITE);
		back.setContentAreaFilled(false);
		back.setBorderPainted(false);
		back.setBounds(100, 225, 100, 100);
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menuflag=-1;
				removeAll();
				System.out.println(menuflag);
			}});;
		this.add(back);
		
		if(menuflag==-1)
		{
			transferFocusUpCycle();
			this.setBounds(28, 500, 0, 0);
			removeAll();
			mainFrame.tag=1;
		}
		if(menuflag==0){
			g.setColor(Color.white);
			Font font = new Font("����", 600, 32);
			g.setFont(font);
			g.drawString("��ͣ", 200, 150);
		}
		if(menuflag==1) {//״̬�˵�
			
			g.setColor(Color.white);
			Font font = new Font("����", 600, 15);
			g.setFont(font);
			g.drawString("����ֵ��"+Player.hp+"/"+Player.hpx, 100, 50);
			g.drawString("ħ��ֵ��"+Player.mp+"/"+Player.mpx, 100, 80);
			g.drawString("��������"+Player.atk, 100, 110);
			g.drawString("��������"+Player.def, 100, 140);
			g.drawString("�ٶȣ�"+Player.spd, 100, 170);
			g.drawString("���ɣ�"+Player.skill, 100, 200);
			g.drawString("�ָ�����"+Player.re, 100, 230);
			g.drawString("�ȼ���"+Player.lv, 230, 50);
			g.drawString("������������ֵ��"+(Player.lv*30-Player.exp), 230, 80);
			g.drawString("���ֽ�Ǯ��"+Player.money, 230, 110);
			//System.out.println("1");
		}
		if(menuflag==2) {//���߲˵�
			g.setColor(Color.white);
			g.drawLine(235, 30, 235, 250);
			if(Player.hppos>0)
			{
				g.drawString("�ָ�ҩˮ��"+Player.hppos, 100, 50);
				JButton use1=new JButton("ʹ��");
				use1.setFont(new Font("����", Font.PLAIN, 10));
				use1.setForeground(Color.RED);
				use1.setContentAreaFilled(false);
				use1.setBorderPainted(false);
				use1.setBounds(150, 20, 100, 50);
				use1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Player.hppos--;
					Player.hp=Player.hpx;
					removeAll();
				}});;
				this.add(use1);
			}
			if(Player.mppos>0) 
			{
				g.drawString("ħ��ҩˮ��"+Player.mppos,100,100);
				JButton use2=new JButton("ʹ��");
				use2.setFont(new Font("����", Font.PLAIN, 10));
				use2.setForeground(Color.RED);
				use2.setContentAreaFilled(false);
				use2.setBorderPainted(false);
				use2.setBounds(150, 70, 100, 50);
				use2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Player.mppos--;
					Player.mp=Player.mpx;
					removeAll();
				}});;
				this.add(use2);
			}
			if(Player.tppos>0) 
			{
				g.drawString("������֮����"+Player.tppos,100,150);
				JButton use3=new JButton("ʹ��");
				use3.setFont(new Font("����", Font.PLAIN, 10));
				use3.setForeground(Color.RED);
				use3.setContentAreaFilled(false);
				use3.setBorderPainted(false);
				use3.setBounds(150, 120, 100, 50);
				use3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Player.tppos--;
					Player.x=725;
					Player.y=875;
					Player.mx=1000;
					Player.my=1000;
					ReadMapFile.readfile("D:\\mygame\\map\\map2.map");
					mainFrame.mapflag=2;
					Player.movepoint=0;
					menuflag=-1;
					removeAll();
				}});;
				this.add(use3);
			}
			if(Player.vopos>0) 
			{
				g.drawString("ʥˮ��"+Player.vopos,100,200);
				JButton use4=new JButton("ʹ��");
				use4.setFont(new Font("����", Font.PLAIN, 10));
				use4.setForeground(Color.RED);
				use4.setContentAreaFilled(false);
				use4.setBorderPainted(false);
				use4.setBounds(150, 170, 100, 50);
				use4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Player.vopos--;
					Player.movepoint=-100;
					removeAll();
				}});;
				this.add(use4);
			}
			if(BattelPanel.swordflag==1) g.drawString("ʥ��",250,50);
		}
		if(menuflag==3) {//���ܲ˵�
			g.setColor(Color.white);
			g.drawLine(235, 30, 235, 250);
			//System.out.println("3");
			g.drawString("����", 100, 50);
			g.drawString("����", 250, 50);
			if(BattelPanel.swordflag==1)
			{
				if(Player.lv>=5) g.drawString("ˮƽն��", 100, 80);
				if(Player.lv>=7) g.drawString("ȫ��һ��", 100, 110);
				if(Player.lv>=9) g.drawString("��֮��", 100, 140);
				if(Player.lv>=13) g.drawString("��֮��", 100, 170);
				if(Player.lv>=15) g.drawString("��ˮ֮��", 100, 200);
			}
			if(Player.lv>=2) g.drawString("����֮����", 250, 80);
			if(Player.lv>=4) g.drawString("����֮����", 250, 110);
			if(Player.lv>=7) g.drawString("����֮����", 250, 140);
			if(Player.lv>=9) g.drawString("�׼�����", 250, 170);
		}
		if(menuflag==4) {//ϵͳ
			JButton save=new JButton("�浵");
			save.setFont(new Font("����", Font.PLAIN, 16));
			save.setForeground(Color.WHITE);
			save.setContentAreaFilled(false);
			save.setBorderPainted(false);
			save.setBounds(100, 20, 100, 70);
			save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					save();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				removeAll();
			}});;
			this.add(save);
			
			JButton load=new JButton("����");
			load.setFont(new Font("����", Font.PLAIN, 16));
			load.setForeground(Color.white);
			load.setContentAreaFilled(false);
			load.setBorderPainted(false);
			load.setBounds(100, 100, 100, 70);
			load.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					load();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				removeAll();
			}});;
			this.add(load);
			
			JButton out=new JButton("�˳���Ϸ");
			out.setFont(new Font("����", Font.PLAIN, 16));
			out.setForeground(Color.WHITE);
			out.setContentAreaFilled(false);
			out.setBorderPainted(false);
			out.setBounds(100, 180, 100, 70);
			out.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}});
				this.add(out);
			//System.out.println("4");
		}
		
	}
	public void save() throws IOException
	{
		File save = new File("save.txt");
		if(!save.exists()){
            save.createNewFile();
        }
		PrintWriter output=new PrintWriter(save);
		output.println(Player.hp);
		output.println(Player.hpx);
		output.println(Player.mp);
		output.println(Player.mpx);
		output.println(Player.atk);
		output.println(Player.def);
		output.println(Player.spd);
		output.println(Player.skill);
		output.println(Player.lv);
		output.println(Player.exp);
		output.println(Player.re);
		output.println(Player.money);
		output.println(Player.movepoint);
		output.println(Player.towards);
		output.println(Player.mx);
		output.println(Player.my);
		output.println(Player.x);
		output.println(Player.y);
		output.println(Player.step);
		output.println(BattelPanel.swordflag);
		output.println(mainFrame.mapflag);
		output.println(Player.hppos);
		output.println(Player.mppos);
		output.println(Player.tppos);
		output.println(Player.vopos);
		output.close();
		System.out.println("save");
	}
	public static void load() throws Exception
	{
		File load=new File("save.txt");
		Scanner input=new Scanner(load);
		while(input.hasNextLine())
		{
			Player.hp=input.nextInt();
			Player.hpx=input.nextInt();
			Player.mp=input.nextInt();
			Player.mpx=input.nextInt();
			Player.atk=input.nextInt();
			Player.def=input.nextInt();;
			Player.spd=input.nextInt();
			Player.skill=input.nextInt();
			Player.lv=input.nextInt();
			Player.exp=input.nextInt();
			Player.re=input.nextInt();
			Player.money=input.nextInt();
			Player.movepoint=input.nextInt();
			Player.towards=input.nextInt();
			Player.mx=input.nextInt();
			Player.my=input.nextInt();
			Player.x=input.nextInt();;
			Player.y=input.nextInt();
			Player.step=input.nextInt();
			BattelPanel.swordflag=input.nextInt();
			mainFrame.mapflag=input.nextInt();
			Player.hppos=input.nextInt();
			Player.mppos=input.nextInt();
			Player.tppos=input.nextInt();
			Player.vopos=input.nextInt();
			input.close();
			if(mainFrame.mapflag==1) ReadMapFile.readfile("map1.map");
			else if(mainFrame.mapflag==2) ReadMapFile.readfile("map2.map");
			else if(mainFrame.mapflag==3) ReadMapFile.readfile("map3.map");
			else if(mainFrame.mapflag==4) ReadMapFile.readfile("map4.map");
		}
	}
}