import javax.swing.JPanel;
public class UpdateThread extends Thread{
	JPanel panel;
	JPanel tpanel;
	JPanel mpanel;
	JPanel bpanel;
	public UpdateThread(JPanel panel,JPanel tpanel,JPanel mpanel,JPanel bpanel) {
		this.panel = panel;
		this.tpanel=tpanel;
		this.mpanel=mpanel;
		this.bpanel=bpanel;
	}
	
	@Override
	public void run() {
		while(true){
			if(mainFrame.tag==1){//���������·״̬��ˢ����Ϸ��ͼ���
				//System.out.println("one");
				panel.repaint();
			}else if(mainFrame.tag==2){//������ڶԻ���״̬��ˢ�¶Ի������
				tpanel.repaint();
			}else if(mainFrame.tag==3) {
				mpanel.repaint();
			}else if(mainFrame.tag==4) {
				//System.out.println("four");
				bpanel.repaint();
			}
			try {
				Thread.sleep(30);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}