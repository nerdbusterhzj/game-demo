import javax.swing.*;
public class GetMap implements gameConfig{
	//ͨ������ƥ��ͼƬ
		static ImageIcon int2icon(int num){
			if(num==0){
				return icon0;
			}
			else 
				if(num==101){
				return icon101;
			}
			else if(num==102){
				return icon102;
			}
			else if(num==103){
				return icon103;
			}
			else if(num==104){
				return icon104;
			}
			else if(num==105){
				return icon105;
			}
			else if(num==106){
				return icon106;
			}
			else if(num==107){
				return icon107;
			}
			else if(num==108){
				return icon108;
			}
			else if(num==109){
				return icon109;
			}
			else if(num==110){
				return icon110;
			}
			else if(num==111){
				return icon111;
			}
			else if(num==112){
				return icon112;
			}
			else if(num==113){
				return icon113;
			}
			else if(num==114){
				return icon114;
			}
			else if(num==115){
				return icon115;
			}
			else if(num==116){
				return icon116;
			}
			else if(num==117){
				return icon117;
			}
			else if(num==118){
				return icon118;
			}
			else if(num==119){
				return icon119;
			}
			else if(num==120){
				return icon120;
			}
			else if(num==121){
				return icon121;
			}
			else if(num==122){
				return icon122;
			}
			else if(num==123){
				return icon123;
			}
			else if(num==124){
				return icon124;
			}
			else if(num==125){
				return icon125;
			}
			else if(num==126){
				return icon126;
			}
			else if(num==127){
				return icon127;
			}
			else if(num==128){
				return icon128;
			}
			else if(num==129){
				return icon129;
			}
			else if(num==401){
				return icon401;
			}
			else if(num==402){
				return icon402;
			}
			else if(num==403){
				return icon403;
			}
			else if(num==404){
				return icon404;
			}
			else if(num==405){
				return icon405;
			}
			else if(num==500){
				return icon500;
			}
			else if(num==500){
				return icon500;
			}
			else if(num==501){
				return icon501;
			}
			else if(num==502){
				return icon502;
			}
			else if(num==503){
				return icon503;
			}
			else if(num==504){
				return icon504;
			}
			else if(num==505){
				return icon505;
			}
			else if(num==506){
				return icon506;
			}
			else if(num==507){
				return icon507;
			}
			else if(num==508){
				return icon508;
			}
			else if(num==509){
				return icon509;
			}
			else if(num==510){
				return icon510;
			}
			else if(num==511){
				return icon511;
			}
			else if(num==600){
				return icon600;
			}
			else if(num==601){
				return icon601;
			}
			else if(num==602){
				return icon602;
			}
			else if(num==603){
				return icon603;
			}
			else if(num==604){
				return icon604;
			}
			else if(num==605){
				return icon605;
			}
			else if(num==606){
				return icon606;
			}
			else if(num==607){
				return icon607;
			}
			else if(num==608){
				return icon608;
			}
			else if(num==609){
				return icon609;
			}
			else if(num==998){
				return icon998;
			}
			else if(num==999){
				return icon999;
			}
			
			return null;
		}
}