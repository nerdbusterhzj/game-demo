import java.awt.Graphics;

import javax.swing.ImageIcon;

public class Player extends Thread implements gameConfig{
	static int px = panelX/2;
	static int py = panelY/2;
	static int x = 725;
	static int y = 875;
	//��ɫ��ƫ����
	static int mx = 1000;
	static int my = 1000;
	//��ɫ�Ĳ���
	static int step = 2;
	//��ɫ�Ƿ��ƶ�
	static boolean up = false;
	static boolean down = false;
	static boolean left = false;
	static boolean right = false;
	static int towards = 2;
	//��ɫ�ƶ���
	static int up1 = 0;
	static int down1 = 0;
	static int left1 = 0;
	static int right1 = 0;
	//��ɫ�ƶ���������ս����
	static int movepoint=0;
	//��ɫ����
	static int hp=70;
	static int hpx=70;
	static int mp=35;
	static int mpx=35;
	static int lv=1;
	static int exp=0;
	static int atk=10;
	static int def=3;
	static int spd=20;
	static int skill=15;
	static int re=5;
	static int money=0;
	
	
	static int hppos=1;//�ָ�ҩ����
	static int mppos=1;//��ҩ����
	static int tppos=0;//�سǵ�������
	static int vopos=1;//ʥˮ
	
	@Override
	public void run() {
		while(true){
			moveUD();
			moveLR();
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	public void moveUD(){
		if(up){
			//����ס�ϼ�ʱ����up1��1����up1����20ʱ������Ϊ0�����ѭ��
			up1++;
			if(up1>=20){
				movepoint++;
				up1=0;
			}
			//�����ɫ��ǰλ���Ϸ�������ֵ��Ϊ0�������ƶ�������һ��
			if(ReadMapFile.map2[y/elesize-1][x/elesize]!=0||(ReadMapFile.map2[y/elesize-1][x/elesize]==0&&ReadMapFile.map3[Player.y/elesize-1][Player.x/elesize]==115)){
				int y1 = (y/elesize-1)*elesize+elesize/2;
				int x1 = (x/elesize)*elesize+elesize/2;
				if((y-y1)*(y-y1)>=elesize*elesize){
					y=y-step;
					my=my-step;
					//System.out.println(my);
				}
			}else if(ReadMapFile.map2[y/elesize-1][x/elesize]==0){//�Ϸ�û���壬���Լ��������ƶ�
				y=y-step;
				my=my-step;
				//System.out.println(my);
			}
		}else if(down){
			down1++;
			if(down1>=20){
				movepoint++;
				down1=0;
			}
			if(ReadMapFile.map2[y/elesize+1][x/elesize]!=0){
				int y1 = (y/elesize+1)*elesize+elesize/2;
				int x1 = (x/elesize)*elesize+elesize/2;
				if((y-y1)*(y-y1)>=elesize*elesize){
					y=y+step;
					my=my+step;
					//System.out.println(my);
				}
			}else if(ReadMapFile.map2[y/elesize+1][x/elesize]==0){
				y=y+step;
				my=my+step;
				//System.out.println(my);
			}
		}
	}
	public void moveLR(){
		if(left){
			left1++;
			if(left1>=20){
				movepoint++;
				left1=0;
			}
			if(ReadMapFile.map2[y/elesize][x/elesize-1]!=0){
				int y1 = (y/elesize)*elesize+elesize/2;
				int x1 = (x/elesize-1)*elesize+elesize/2;
				if((x-x1)*(x-x1)>=elesize*elesize){
					x=x-step;
					mx=mx-step;
					//System.out.println(mx);
				}
			}else if(ReadMapFile.map2[y/elesize][x/elesize-1]==0){
				x=x-step;
				mx=mx-step;
				//System.out.println(mx);
			}
		}else if(right){
			right1++;
			if(right1>=20){
				movepoint++;
				right1=0;
			}
			if(ReadMapFile.map2[y/elesize][x/elesize+1]!=0){
				int y1 = (y/elesize)*elesize+elesize/2;
				int x1 = (x/elesize+1)*elesize+elesize/2;
				if((x-x1)*(x-x1)>=elesize*elesize){
					x=x+step;
					mx=mx+step;
				//	System.out.println(mx);
				}
			}else if(ReadMapFile.map2[y/elesize][x/elesize+1]==0){
				x=x+step;
				mx=mx+step;
				//System.out.println(mx);
			}
		}
	}
	public static void draw(Graphics g){
		ImageIcon walk=iconplayer1;
		if(BattelPanel.swordflag==1) 
		{
				walk = iconplayer;
		}
		//�����ɫ�����ƶ���
		if(!up&&!down&&!left&&!right){
			if(towards==1){//�����ɫ�ƶ��������Ϊ��
				g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 0, 50*3, 50, 50*4, null);
			}else if(towards==2){//����ƶ�������
				g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 0, 0, 50, 50, null);
			}else if(towards==3){//����ƶ�������
				g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 0, 50, 50, 50*2, null);
			}else if(towards==4){//����ƶ�������
				g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 0, 50*2, 50, 50*3, null);
			}
		}else{//�����ɫ���ƶ���
			if(up){
				//ͨ��up1��ֵ������������һ��ͼƬ
				if(up1<5){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 0, 50*3, 50, 50*4, null);
				}else if(up1<10){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50, 50*3, 50*2, 50*4, null);
				}else if(up1<15){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50*2, 50*3, 50*3, 50*4, null);
				}else{
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50*3, 50*3,50*4, 50*4, null);
				}
			}else if(down){
				if(down1<5){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 0, 0, 50,50, null);
				}else if(down1<10){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50, 0, 50*2, 50, null);
				}else if(down1<15){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50*2, 0, 50*3, 50, null);
				}else{
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50*3, 0, 50*4, 50, null);
				}
			}else if(left){
				if(left1<5){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 0, 50, 50, 50*2, null);
				}else if(left1<10){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50, 50, 50*2, 50*2, null);
				}else if(left1<15){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50*2, 50, 50*3, 50*2, null);
				}else{
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50*3, 50, 50*4, 50*2, null);
				}
				
			}else if(right){
				if(right1<5){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 0, 50*2, 50, 50*3, null);
				}else if(right1<10){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50, 50*2, 50*2, 50*3, null);
				}else if(right1<15){
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50*2, 50*2, 50*3, 50*3, null);
				}else{
					g.drawImage(walk.getImage(), Player.px-elesize/2, Player.py-elesize/2-15, Player.px-elesize/2+45, Player.py-elesize/2+35, 50*3, 50*2, 50*4, 50*3, null);
				}
			}
		}
	}
	public static int getI(){
		return (y-(playersize/2))/50;
	}
	//�õ���ɫ�������е�λ��J
	public static int getJ(){
		return (x-(playersize/2))/50;
	}
}