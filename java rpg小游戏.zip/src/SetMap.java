import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import javax.swing.*;
public class SetMap extends JFrame implements MapConfig{//����Ҳ�ǵ�ͼ�༭����������
	//����ѡ���زĵ�������(ǰ��)
	JComboBox<ImageIcon> box;
	//����ѡ���زĲ�����������
	JComboBox<Integer> boxtype;
	//�������潨���ĵ�ͼ����Ķ�ά����   (map1�����ز�   map2�ر��ز�   map3�ϲ��ز�)
	static int[][] map1 = new int[40][40];
	static int[][] map2 = new int[40][40];
	static int[][] map3 = new int[40][40];
	static ImageIcon[][] icons1 = new ImageIcon[40][40];
	static ImageIcon[][] icons2 = new ImageIcon[40][40];
	static ImageIcon[][] icons3 = new ImageIcon[40][40];
	//�༭�еĵ�ͼ��ʾ�����
	static JPanel panel;
	public static void main(String[] args) {
		SetMap sm = new SetMap();
		sm.init();
	}
	public void init(){
		this.setTitle("��ͼ��������");
		this.setSize(1000, 700);
		this.setDefaultCloseOperation(3);
		this.setLayout(new FlowLayout());
		//���������
		panel = new MySetPanel();
		panel.setPreferredSize(new Dimension(MapWidth, MapHeight));
		JScrollPane jsp = new JScrollPane(panel);
		jsp.setPreferredSize(new Dimension(600, 600));
		jsp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		
		boxtype = new JComboBox<Integer>();
		boxtype.addItem(1);
		boxtype.addItem(2);
		boxtype.addItem(3);
		
		box = new JComboBox<ImageIcon>();
		setBox(box);
		
		JButton create = new JButton("����");
		create.setActionCommand("create");
		
		this.add(jsp);
		this.add(boxtype);
		this.add(box);
		this.add(create);
		this.setVisible(true);
		
		PanelListenner plis = new PanelListenner();
		panel.addMouseListener(plis);
		Buttonlistenner blis = new Buttonlistenner();
		create.addActionListener(blis);
	}
	public void setBox(JComboBox box){
		for(int i=0;i<allicons.length;i++){
			box.addItem(allicons[i]);
		}
	}
class MySetPanel extends JPanel{
		
		@Override
		public void paint(Graphics g) {
			super.paint(g);
			for(int i=0;i<MapHeight/eleHeight;i++){
				for(int j=0;j<MapWidth/eleWidth;j++){
					//����һ��Ԫ��
					if(icons1[i][j]!=null){
						g.drawImage(icons1[i][j].getImage(), getDrawX(j), getDrawY(i), eleWidth, eleHeight, null);
					}
					//���ڶ���Ԫ��
					if(icons2[i][j]!=null){
						g.drawImage(icons2[i][j].getImage(), getDrawX(j), getDrawY(i), eleWidth, eleHeight, null);
					}
					//��������Ԫ��
					if(icons3[i][j]!=null){
						g.drawImage(icons3[i][j].getImage(), getDrawX(j), getDrawY(i), eleWidth, eleHeight, null);
					}
				}
			}
		}
		
		//�������±�ת���ɶ�Ӧ��ͼƬ���Ͻ�����
		public int getDrawX(int j){
			int x = j*50;
			return x;
		}
		//�������±�ת���ɶ�Ӧ��ͼƬ���Ͻ�����
		public int getDrawY(int i){
			int y = i*50; 	
			return y;
		}
	}
class Buttonlistenner implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("create")){
			try{
			System.out.println("��ʼ����");
			FileOutputStream fos = new FileOutputStream(path);
			DataOutputStream dos = new DataOutputStream(fos);
			int i = MapHeight/eleHeight;
			int j = MapWidth/eleWidth;
			//������Ĵ�Сд���ļ�
			dos.writeInt(i);
			dos.writeInt(j);
			for(int ii=0;ii<i;ii++){
				for(int jj=0;jj<j;jj++){
					dos.writeInt(map1[ii][jj]);
					dos.writeInt(map2[ii][jj]);
					dos.writeInt(map3[ii][jj]);
				}
			}
			dos.flush();
			dos.close();
			System.out.println("�������");
			
			}catch(Exception ef){
				ef.printStackTrace();
			}
		}
	}
}

class PanelListenner extends MouseAdapter{
	public void mouseClicked(MouseEvent e) {
		//�õ���λ�ö�Ӧ�������±�
		int j = e.getX()/eleWidth;
		int i = e.getY()/eleHeight;
		System.out.println(i+"<>"+j);
		ImageIcon icon = (ImageIcon)box.getSelectedItem();
		int num = str2int(icon.toString().substring(0, 3));
		if((int)boxtype.getSelectedItem()==1){
			map1[i][j] = num;
			icons1[i][j] = icon;
		}else if((int)boxtype.getSelectedItem()==2){
			map2[i][j] = num;
			icons2[i][j] = icon;
		}else if((int)boxtype.getSelectedItem()==3){
			map3[i][j] = num;
			icons3[i][j] = icon;
		}
		System.out.println((int)boxtype.getSelectedItem());
		
		panel.repaint();
	}
	
	public int str2int(String numstr){
		for(int i=0;i<3;i++){
			if(numstr.charAt(i)!=0){
				numstr = numstr.substring(i);
				int num = Integer.parseInt(numstr);
				return num;
			}
		}
		numstr = numstr.substring(2);
		int num = Integer.parseInt(numstr);
		return num;
	}
	
}
}