﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float a = Input.GetAxis("Horizontal");//当按下的左右方向（a,d 方向键的左右 4,6）时获取到一个-1到1的值
        float b = Input.GetAxis("Vertical");//当按下的上下方向（w,s 方向键的上下 8,2）时获取到一个-1到1的值
        float m = Input.GetAxis("Mouse ScrollWheel");//鼠标滚轮缩放
        transform.Translate(new Vector3(a, m, b) * Time.deltaTime * 50, Space.World);//转为世界坐标移动
        
    }
}
