﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class continuegame : MonoBehaviour
{
    public Button continuebutton;

    public GameObject pausepanel;
    // Start is called before the first frame update
    void Start()
    {
        continuebutton = GetComponent<Button>();
        continuebutton.onClick.AddListener(return_to_game);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void return_to_game()
    {
        pause.pauseflag = false;
        Time.timeScale = 1;
        pausepanel.SetActive(false);
    }
}
