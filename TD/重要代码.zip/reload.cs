﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class reload : MonoBehaviour
{
    public Button restartgamebutton;

    // Start is called before the first frame update
    void Start()
    {
        restartgamebutton = GetComponent<Button>();
        restartgamebutton.onClick.AddListener(re_load_game);


    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void re_load_game()
    {
        SceneManager.LoadScene("gamescene");
        pause.pauseflag = false;
        Time.timeScale = 1;

        gamemanager.atkwave = 0;
        gamemanager.fail = false;
        gamemanager.hp = gamemanager.Max_HP;
        gamemanager.money = 1000;
        gamemanager.socre = 0;
        
    }
}
