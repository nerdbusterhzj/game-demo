﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class infoctrl : MonoBehaviour
{
    public Text waveinfo;
    public Text hpinfo;
    public Text moneyinfo;
    public Text socreinfo;

    // Start is called before the first frame update
    void Start()
    {
        waveinfo = GameObject.Find("Canvas/infoPanel/wavenum").GetComponent<Text>();
        hpinfo = GameObject.Find("Canvas/infoPanel/hpnum").GetComponent<Text>();
        moneyinfo = GameObject.Find("Canvas/infoPanel/money").GetComponent<Text>();
        socreinfo = GameObject.Find("Canvas/infoPanel/socre").GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        waveinfo.text = gamemanager.atkwave.ToString();
        hpinfo.text = gamemanager.hp.ToString() + " / " + gamemanager.Max_HP.ToString();
        moneyinfo.text = gamemanager.money.ToString();
        socreinfo.text = gamemanager.socre.ToString();


    }
}
