﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gamemanager : MonoBehaviour
{
    public static gamemanager Instance;
    public ArrayList Enemys = new ArrayList();
    public static int atkwave=0;
    public bool IsWin = false;
    public static int Max_HP=20;//玩家血量上限
    public static int hp;
    public static int money = 1000;
    public static int socre = 0;
    public static bool fail = false;

    public GameObject winpanel;
    public GameObject failpanel;

    // Start is called before the first frame update
    void Start()
    {
        Instance = this;
        hp = Max_HP;
        GameObject[] _all = GameObject.FindGameObjectsWithTag("Enemy");
        Debug.Log(_all.Length);
        foreach (GameObject go in _all)
        {
            Enemys.Add(go.GetComponent<enemy>());
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (hp <= 0)
        {
            fail = true;
            failpanel.SetActive(true);

        }
        if(IsWin)
        {
            winpanel.SetActive(true);
        }
    }
}
