﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class beam : MonoBehaviour
{
    private Transform tr;
    private LineRenderer line;
    private RaycastHit hit;
    public float damage = 1.5f;
   // public AudioClip firesfx;
   // private AudioSource Source=null;

    public float atktime = 1.0f;//攻击间隔
    public float mtime = 0;

    // Start is called before the first frame update
    void Start()
    {
        //Source = GetComponent<AudioSource>();
        tr = GetComponent<Transform>();
        line = GetComponent<LineRenderer>();
        line.useWorldSpace = false;
        line.enabled = true;
        line.SetWidth(2.0f, 2.0f);
    }

    // Update is called once per frame
    void Update()
    {
        Ray ray = new Ray(tr.position + (Vector3.up * 0.02f), tr.forward);
        Debug.DrawRay(ray.origin, ray.direction * 100, Color.blue);
        if(towerctrl.e_target!=null)
        {
            //Source.Play();
            line.enabled = true;
            //Source.gameObject.SetActive(true);
            //Source.PlayOneShot(firesfx, 0.5f);
            
            line.SetPosition(0, tr.InverseTransformPoint(ray.origin));
            if(Physics.Raycast(ray,out hit,100.0f))
            {
                line.SetPosition(1, tr.InverseTransformPoint(hit.point));
            }
            else
            {
                line.SetPosition(1, tr.InverseTransformPoint(ray.GetPoint(100.0f)));
            }
            mtime -= Time.deltaTime;
            if (mtime < 0)
            {
                towerctrl.e_target.setdamage(damage);
                mtime = atktime;
            }
            //StartCoroutine(this.showbeam());

        }
        else 
        {
            line.enabled = false;
            //Source.gameObject.SetActive(false);
            //Source.PlayOneShot(firesfx, 0.0f);
            //Source.Pause();
        }
        
    }
    //IEnumerator showbeam()
    //{
        //line.enabled = true;
        //yield return new WaitForSeconds(Random.Range(0.01f, 0.2f));
        //towerctrl.e_target.setdamage(damage);
        //line.enabled = false;
    //}
}
