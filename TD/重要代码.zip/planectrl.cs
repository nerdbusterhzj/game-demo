﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class planectrl : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter(Collision coll)
    {
        if(coll.collider.tag=="Bullet")
        {
            Destroy(coll.gameObject);
        }
        if(coll.collider.tag=="Rocket")
        {
            Destroy(coll.gameObject);
        }
    }
}
