﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawndata : MonoBehaviour
{
    public int wave;
    public string enemyname;
    public int level;
    public float wait;




    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
