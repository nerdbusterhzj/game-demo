﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class towerpanel : MonoBehaviour
{
    public Button sellbutton;
    public Button lvupbutton;

    private int t1_up_money = 30;
    private int t2_up_money = 50;
    private int t3_up_money = 80;

    public towerctrl tower;
    // Start is called before the first frame update
    void Start()
    {
        sellbutton = GameObject.Find("Canvas/sell").GetComponent<Button>();
        lvupbutton = GameObject.Find("Canvas/lvup").GetComponent<Button>();

        tower = GetComponentInParent<towerctrl>();

        sellbutton.onClick.AddListener(sell);
        lvupbutton.onClick.AddListener(lvup);

    }

    // Update is called once per frame
    void Update()
    {
        transform.rotation = Camera.main.transform.rotation;
    }
    void sell()
    {
        if(tower.towertype==1)
        {
            gamemanager.money += 5;
        }
        else if(tower.towertype==2)
        {
            gamemanager.money += 10;
        }
        else if(tower.towertype==3)
        {
            gamemanager.money += 20;
        }
        tower.destroy();

    }
    void lvup()
    {
        if(tower.towertype==1)
        {
            if(gamemanager.money<t1_up_money)
            {
                panelctrl.moneyout = true;
                return;
            }
            else
            {
                tower.atkdist = tower.atkdist * 2;
                gamemanager.money -= t1_up_money;
                t1_up_money = t1_up_money * 2;
                tower.tower.gameObject.SetActive(false);
            }
        }
        else if(tower.towertype == 2)
        {
            if(gamemanager.money<t2_up_money)
            {
                panelctrl.moneyout = true;
                return;
            }
            else
            {
                tower.atkdist = tower.atkdist * 2;
                gamemanager.money -= t2_up_money;
                t2_up_money = t2_up_money * 2;
                tower.tower.gameObject.SetActive(false);
            }
        }
        else if(tower.towertype == 3)
        {
            if(gamemanager.money<t3_up_money)
            {
                panelctrl.moneyout = true;
                return;
            }
            else
            {
                tower.atkdist = tower.atkdist * 2;
                gamemanager.money -= t3_up_money;
                t3_up_money = t3_up_money * 2;
                tower.tower.gameObject.SetActive(false);
            }
        }
    }
}
