﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rocketbullet : MonoBehaviour
{
    public float speed = 1000.0f;
    public static float damage = 5.0f;
    // Start is called before the first frame update
    void Start()
    {
        GetComponent<Rigidbody>().AddForce(transform.up * -speed);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
