﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class pause : MonoBehaviour
{

    public Button pausebutton;

    public GameObject pausepanel;

    public static bool pauseflag = false;
    // Start is called before the first frame update
    void Start()
    {
        pausebutton = GameObject.Find("Canvas/pause").GetComponent<Button>();
        pausebutton.onClick.AddListener(pauseact);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void pauseact()
    {
        pauseflag = true;
        if (pauseflag)
        {
            Time.timeScale = 0;

        }
        pausepanel.SetActive(true);




    }
}
