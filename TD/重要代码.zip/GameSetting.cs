﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameSetting : MonoBehaviour
{
    public AudioClip clip;
    public AudioSource btnsource;
    public AudioSource bgsource;
    //public static bool VoiceSwitch = true;
    public Scrollbar voice;
    public Slider volume;
    public Slider BtnSlider;
    public static float bgvolume;
    public static float btnvolume;

    public static float nowbgv=1.0f;
    public static float nowbtv=1.0f;

    public static float voicevol =0;
    /*public void Awake()//重写Awake函数
    {
        music = this.transform.GetComponent<AudioSource>();//获取音频源组件
    }*/

    public void click()
    {
        Debug.Log(voicevol);
        voice.value = voicevol;
        //Voice();
       // Voice();
        //Debug.Log(VoiceSwitch);
        if(voicevol<=0.5 )
            btnsource.PlayOneShot(clip);
    }

    //声音开关
    public void Voice()
    {
        if (voicevol <= 0.5)
        {
            //VoiceSwitch = true;
            bgsource.gameObject.SetActive(true);
            btnsource.gameObject.SetActive(true);
            voicevol = voice.value;

        }
        else if(voicevol > 0.5)
        {
            //VoiceSwitch = false;
            bgsource.gameObject.SetActive(false);
            btnsource.gameObject.SetActive(false);
            voicevol = voice.value;
        }
    }
    //背景音乐音量调整
    public  void SetBgVolume(float f)
    {
        PlayerPrefs.GetFloat("BackgroundMusic",f);
    }
    private float GetBgVolume()
    {
        return PlayerPrefs.GetFloat("BackgroundMusic", 1f);
    }
    public void changeVolue_music()
    {
        bgvolume = volume.value;
        nowbgv = bgvolume;
        bgsource.volume = volume.value;//现在滑条值
        SetBgVolume(volume.value);//将滑条值改变反应到音量上
    }
    // Start is called before the first frame update
    void Start()
    {
        Voice();
        Debug.Log(voicevol);
        voice.value = voicevol;
        bgvolume = nowbgv;
        bgsource.volume = bgvolume;
        volume.value = bgsource.volume;

        btnvolume = nowbtv;
        btnsource.volume = btnvolume;
        BtnSlider.value = btnsource.volume;
    }
    //按钮音量调整
    public void SetBtnVolume(float f)
    {
        PlayerPrefs.GetFloat("Audio Source", f);
    }
    private float GetBtnVolume()
    {
        return PlayerPrefs.GetFloat("Audio Source", 1f);
    }
    public void changeVolue_Btn()
    {
        btnvolume = BtnSlider.value;
        nowbtv = btnvolume;
        btnsource.volume = BtnSlider.value;
        SetBtnVolume(BtnSlider.value);
    }
    // Update is called once per frame
    void Update()
    {
        
    }

}
