﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class exposound : MonoBehaviour
{
    public AudioClip esfx;
    public AudioSource esource = null;
    // Start is called before the first frame update
    void Start()
    {
        esource = GetComponent<AudioSource>();
        esource.PlayOneShot(esfx, 1.0f);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
