﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class bulid : MonoBehaviour
{
    public static bool bulidflag = false;
    //public GameObject towerPrefab;
    //private GameObject tower;
    private Color CubeColor;
    //public GameObject objCube;
    // Start is called before the first frame update
    void Start()
    {
        
        this.GetComponent<Renderer>().material.color = Color.gray;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //private bool canPlaceTower()
    //{
       // return tower == null;
   // }
    private void OnMouseUp()
    {
        
        //if (canPlaceTower())
        //{
            bulidflag = true;
            panelctrl.buildplace = this.transform;//把建造地点贮存在面板上
           // Tower = (GameObject)Instantiate(TowerPrefab, transform.position, Quaternion.identity);

        //}
    }
    private void OnMouseOver()
    {
        if (!bulidflag)
        {
            this.GetComponent<Renderer>().material.color = Color.red;
        }

    }
    private void OnMouseExit()//鼠标离开按钮上方，按钮颜色复位
    {
        if(!bulidflag)
        {
            this.GetComponent<Renderer>().material.color = Color.gray;
        }
        
        
    }

}
