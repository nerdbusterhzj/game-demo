﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class scorechange : MonoBehaviour
{
    public Text socrepoint;
    public Text d_num;

    // Start is called before the first frame update
    void Start()
    {
        socrepoint.text = gamemanager.socre.ToString();
        d_num.text= (2*gamemanager.socre / 100).ToString();
        PlayerInf.D_num+= 2*gamemanager.socre / 100;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
