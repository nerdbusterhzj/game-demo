﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Store : MonoBehaviour
{
    public Text STtips;
    public GameObject PLAYERINF;
    public Text STDiamond_text;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void  Init()
    {
        STtips.gameObject.SetActive(false);
        STDiamond_text.text = PLAYERINF.GetComponent<PlayerInf>().Diamond.ToString();
    }
    public void STbuy()
    {
        if (PLAYERINF.GetComponent<PlayerInf>().Diamond >= 50)
        {

            PLAYERINF.GetComponent<PlayerInf>().CHDiamond(-50);
            STDiamond_text.text = PLAYERINF.GetComponent<PlayerInf>().Diamond.ToString();
            PLAYERINF.GetComponent<PlayerInf>().CHGoodsCount(Goods.AntimatterBomb, 1);
        }
        else
            STtips.gameObject.SetActive(true);
    }
}
