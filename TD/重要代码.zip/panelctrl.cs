﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class panelctrl : MonoBehaviour
{
    public static Transform buildplace;
    public GameObject TowerPrefab1;
    public GameObject TowerPrefab2;
    public GameObject TowerPrefab3;
    public GameObject Tower;
    public int bulidp=0;
    public static bool moneyout=false;

    CanvasGroup bulidpanel;

    public Button button1;
    public Button button2;
    public Button button3;

    public float mtime = 0.25f;
    public float wtime = 0.25f;

   

    // Start is called before the first frame update
    void Start()
    {
        bulidpanel = GetComponent<CanvasGroup>();
        button1 = GameObject.Find("Canvas/BulidPanel/Button1").GetComponent<Button>();
        button2 = GameObject.Find("Canvas/BulidPanel/Button2").GetComponent<Button>();
        button3 = GameObject.Find("Canvas/BulidPanel/Button3").GetComponent<Button>();
        button1.onClick.AddListener(onClick1);
        button2.onClick.AddListener(onClick2);
        button3.onClick.AddListener(onClick3);
    }

    // Update is called once per frame
    void Update()
    {
        moneyout_m();
        if(bulid.bulidflag==true)
        {
            bulidpanel.alpha = 1;
            bulidpanel.blocksRaycasts = true;
            bulidpanel.interactable = true;
        }
        else
        {
            bulidpanel.alpha = 0;
            bulidpanel.blocksRaycasts = false;
            bulidpanel.interactable = false;
        }
        if(Input.GetMouseButtonDown(1))
        {
            bulid.bulidflag = false;
        }
        
        
    }
    void onClick1()//建造一号塔
    {
        //Debug.Log("bulid1");
        bulidp = 10;
        if(gamemanager.money<bulidp)
        {
            Debug.Log("钱不够");
            moneyout = true;
            bulidp = 0;
            return;
        }
        Tower = (GameObject)Instantiate(TowerPrefab1, buildplace.position, Quaternion.identity);
        Tower.transform.localScale = new Vector3(1, 1, 1);

        gamemanager.money -= 10;
        bulidp = 0;
        bulid.bulidflag = false;
        moneyout = false;
        //Tower = null;
    }
    void onClick2()
    {   
        if(!PlayerInf.TD_2)
        {
            return;
        }
        //Debug.Log("bulid2");
        bulidp = 20;
        if (gamemanager.money < bulidp)
        {
            Debug.Log("钱不够");
            moneyout = true;
            bulidp = 0;
            return;
        }
        Tower = (GameObject)Instantiate(TowerPrefab2, buildplace.position, Quaternion.identity);
        Tower.transform.localScale = new Vector3(1, 1, 1);
        gamemanager.money -= 20;
        bulidp = 0;
        bulid.bulidflag = false;
        moneyout = false;
        //Tower = null;
    }
    void onClick3()
    {
        if(!PlayerInf.TD_3)
        {
            return;
        }
        bulidp = 40;
        //Debug.Log("bulid3");
        if (gamemanager.money < bulidp)
        {
            Debug.Log("钱不够");
            moneyout = true;
            bulidp = 0;
            return;
        }
        Tower = (GameObject)Instantiate(TowerPrefab3, buildplace.position, Quaternion.identity);
        Tower.transform.localScale = new Vector3(1, 1, 1);
        gamemanager.money -= 40;
        bulidp = 0;
        bulid.bulidflag = false;
        moneyout = false;
        // Tower = null;
    }
    public void moneyout_m()
    {
        if(moneyout)
        {
            wtime -= Time.deltaTime;
            if (wtime < 0)
            {
                moneyout = false;
                wtime = mtime;
            }
        }
    }
    

}
