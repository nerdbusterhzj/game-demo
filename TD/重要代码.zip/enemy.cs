﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class enemy : MonoBehaviour
{
    public int enemytype;
    public float max_hp=10;
    public float hp=10;
    public int level=0;


    public Slider enemyhpbar;
    public GameObject bullethiteffect;
    public GameObject rockethiteffect;
    public GameObject dieeffect;

    public int test=0;

    // Start is called before the first frame update
    
    void Start()
    {
        gamemanager.Instance.Enemys.Add(this.GetComponent<enemy>());
        //enemyhpbar = GameObject.Find("enemy/Canvas/HPSlider").GetComponent<Slider>();
        enemyhpbar.value = enemyhpbar.maxValue = max_hp;
    }

    // Update is called once per frame
    void Update()
    {

        enemyhpbar.value = hp;
        setdamage(test);
        pointcheck();

        
    }
    public void setdamage(float mvalue)
    {
        hp -= mvalue;
        if(hp<=0)
        {
            gamemanager.money += level * 5;
            gamemanager.socre += level * 100;

            
            GameObject die = (GameObject)Instantiate(dieeffect, this.transform.position, Quaternion.identity);
            Destroy(die, die.GetComponent<ParticleSystem>().main.duration);

            
            gamemanager.Instance.Enemys.Remove(this.GetComponent<enemy>());
            Destroy(this.gameObject);
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "Bullet")
        {
            GameObject spark=(GameObject)Instantiate(bullethiteffect, collision.transform.position, Quaternion.identity);
            Destroy(spark, spark.GetComponent<ParticleSystem>().main.duration-4.5f);
            setdamage(gunbullet.damage);
            Destroy(collision.gameObject);
        }
        if (collision.collider.tag == "Rocket")
        {
            GameObject spark = (GameObject)Instantiate(rockethiteffect, collision.transform.position, Quaternion.identity);
            Destroy(spark, spark.GetComponent<ParticleSystem>().main.duration-1.5f);
            setdamage(rocketbullet.damage);
            Destroy(collision.gameObject);
        }
    }
    void pointcheck()
    {
        if (Vector3.Distance(this.transform.position,enemyfindtheway.FP.position)<=11.0f)
        {
            Debug.Log("抵达");
            gamemanager.hp -= 1;//减血
            gamemanager.Instance.Enemys.Remove(this.GetComponent<enemy>());
            Destroy(this.gameObject);
        }
    }
}
