﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TDStore : MonoBehaviour
{
    public GameObject PLAYERINF;
    public GameObject TIPS;
    public GameObject MAINUI;
    public  Button TDNext_Btn;
    public  Button TDPrev_Btn;
    public Button BuyTD_Btn;
    public  Text TD_text;
    public  Text TDPrices_te;
    public  Text TDdiamond;
    public Text buytips;
    public Text intrrouce;
    public Image TD1_img;
    public Image TD1_imgs;
    public Image TD2_img;
    public Image TD2_imgs;
    public Image TD3_img;
    public Image TD3_imgs;
    public int TD_count;
    public const int TD_MAX = 6;
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("TDStart " + MAINUI.GetComponent<mainUI>().PanelTD.activeInHierarchy);
        buytips.gameObject.SetActive(false);
        MAINUI.GetComponent<mainUI>().PanelTD.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //面板初始化
    public void PanelInit()
    {
        TD_count=0;
        TDInti();
        TD1();
        TDPrev_Btn.gameObject.SetActive(false);
        TDNext_Btn.gameObject.SetActive(true);
        TDdiamond.text = PLAYERINF.GetComponent<PlayerInf>().Diamond.ToString();
    }
    public void TDNext()
    {
        buytips.gameObject.SetActive(false);
        TD_count++;
        if (TD_count > 2)
            TD_count = 2;
        if (TD_count > 0 && TD_count <= 2)
            TDPrev_Btn.gameObject.SetActive(true);
        if (TD_count == 2)
            TDNext_Btn.gameObject.SetActive(false);
        TDDisplay();
    }
    public void TDPrev()
    {
        buytips.gameObject.SetActive(false);
        TD_count--;
        if (TD_count < 0)
            TD_count = 0;
        if (TD_count < 2)
            TDNext_Btn.gameObject.SetActive(true);
        if (TD_count == 0)
            TDPrev_Btn.gameObject.SetActive(false);
        TDDisplay();
    }
    public void TDDisplay()
    {

        switch (TD_count)
        {
            case 0: TD1(); break;
            case 1: TD2(); break;
            case 2: TD3(); break;
            default: break;
        }
    }
    //图片初始化
    public  void TDInti()
    {
        TD1_imgs.gameObject.SetActive(false);
        TD1_img.gameObject.SetActive(false);
        TD2_img.gameObject.SetActive(false);
        TD2_imgs.gameObject.SetActive(false);
        TD3_img.gameObject.SetActive(false);
        TD3_imgs.gameObject.SetActive(false);
    }
    public  void TD1()
    {
        BuyTD_Btn.gameObject.SetActive(false);
        TD_text.text = "炮塔";
        TDPrices_te.text = "0";
        intrrouce.text = "伤害低，射速高，范围一般";
        TDInti();
        TD1_imgs.gameObject.SetActive(true);
        TD1_img.gameObject.SetActive(true);
    }
    public void TD2()
    {
        BuyTD_Btn.gameObject.SetActive(true);
        TD_text.text = "激光塔";
        intrrouce.text = "伤害低，射速一般" +
            "，范围广";
        if (PLAYERINF.GetComponent<PlayerInf>().TD(2))
        {
            TDPrices_te.text = "0";
            BuyTD_Btn.enabled = false;
        }
        else
            TDPrices_te.text = "100";
        TDInti();
        TD2_img.gameObject.SetActive(true);
        TD2_imgs.gameObject.SetActive(true);
    }
    public  void TD3()
    {
        BuyTD_Btn.gameObject.SetActive(true);
        TD_text.text = "导弹塔";
        intrrouce.text = "伤害高，范围一般，射速低";
        if (PLAYERINF.GetComponent<PlayerInf>().TD(3))
        {
            TDPrices_te.text = "0";
            BuyTD_Btn.enabled = false;
        } 
        else
            TDPrices_te.text = "200";
        TDInti();
        TD3_img.gameObject.SetActive(true);
        TD3_imgs.gameObject.SetActive(true);
    }
    public void Buy()
    {
        Debug.Log("TDBUY " + MAINUI.GetComponent<mainUI>().PanelTD.activeInHierarchy);
        
        switch (TD_count)
        {
            case 1:
                if (PLAYERINF.GetComponent<PlayerInf>().Diamond >= 100)
                {
                    TDPrices_te.text = "0";
                    PLAYERINF.GetComponent<PlayerInf>().CHDiamond(-100);
                    TDdiamond.text = PLAYERINF.GetComponent<PlayerInf>().Diamond.ToString();
                    PLAYERINF.GetComponent<PlayerInf>().CHTD(2);

                    
                   // MAINUI.GetComponent<mainUI>().PanelTD.SetActive(true);
                    //TIPS.GetComponent<Tips>().TipsInin();
                    //TIPS.GetComponent<Tips>().tips3.gameObject.SetActive(true);
                   // TIPS.GetComponent<Tips>().Clo_Btn.gameObject.SetActive(true);
                    //TIPS.GetComponent<Tips>().Paneltips.SetActive(true);
                }
                else
                    buytips.gameObject.SetActive(true);
                break;
            case 2:
                if (PLAYERINF.GetComponent<PlayerInf>().Diamond >= 200)
                {
                    TDPrices_te.text = "0";               
                    PLAYERINF.GetComponent<PlayerInf>().CHDiamond(-200);
                    TDdiamond.text = PLAYERINF.GetComponent<PlayerInf>().Diamond.ToString();
                    PLAYERINF.GetComponent<PlayerInf>().CHTD(3);

                   

                    //TIPS.GetComponent<Tips>().TipsInin();
                    //TIPS.GetComponent<Tips>().tips3.gameObject.SetActive(true);
                    //TIPS.GetComponent<Tips>().Clo_Btn.gameObject.SetActive(true);
                   //TIPS.GetComponent<Tips>().Paneltips.SetActive(true);
                }
                else
                    buytips.gameObject.SetActive(true);
                break;
            default: break;
        }
    }
}
