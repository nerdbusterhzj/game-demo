﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public  enum PrevPanel
{
    PanelStart,
    PanelSettings,
    PanelArchive,
    PanelGameMode,
    PanelCheckPoint,
    PanelPause,
    PanelTD,
    PanelStore,
    PanelBackpack
}
public class mainUI : MonoBehaviour
{
   

    public GameObject PanelStart;
    public GameObject PanelSettings;
    public GameObject PanelArchive;
    public GameObject PanelGameMode;
    public GameObject PanelCheckPoint;
    public GameObject PanelPause;
    public GameObject PanelTD;
    public GameObject PanelStore;
    public GameObject PanelBackpack;
    public GameObject PanelVictory;
    public GameObject PanelDefeat;
    public GameObject Paneltips;
    public GameObject Paneldevelop;
    public GameObject PanelT;

    public GameObject PLAYERINF;
    public GameObject TDSTORE;
    public GameObject TIPS;
    public GameObject STORE;
    
    //public Button STNext_Btn;
    //public Button STPrev_Btn;
   
    public Button Yes_Btn;
    public Button NO_Btn;
    public Button Clo_Btn;
    
    public Text ST_text;
    public Text Diamond_text;
   
    public Text VicScore_te;
    public Text VicReward_te;
    public Text DefScore_te;
    public Text DefReward_te;
    //public Text STtips;
    public Text BPBoom;
    public int ST_count;
   // public bool showtip=false;
    public PrevPanel prevpanel;//上级菜单
    public int prescene=0;//上级场景
    
    // Start is called before the first frame update
    void Start()
    {
        prevpanel = PrevPanel.PanelStart;
        PanelTD.SetActive(false);
        PanelT.SetActive(false);
        PanelSettings.SetActive(false);
        PanelPause.SetActive(false);
        PanelArchive.SetActive(false);
        PanelCheckPoint.SetActive(false);
        PanelGameMode.SetActive(false);
        PanelStart.SetActive(true);
        PanelStore.SetActive(false);
        PanelBackpack.SetActive(false);
        PanelDefeat.SetActive(false);
        PanelVictory.SetActive(false);
        Paneltips.SetActive(false);
        Paneldevelop.SetActive(false);
        TDSTORE.GetComponent<TDStore>().buytips.gameObject.SetActive(false);
        Debug.Log("mainstart presene="+prescene.ToString());
        
    }

    // Update is called once per frame
    void Update()
    {
        if (prescene == 20)
        {
            PanelStart.SetActive(false);
            PanelSettings.SetActive(true);
        }
        Debug.Log("mainupdate presene=" + prescene.ToString());
    }
    public void PanelInit()
    {
        PanelTD.SetActive(false);
        PanelSettings.SetActive(false);
        PanelPause.SetActive(false);
        PanelArchive.SetActive(false);
        PanelCheckPoint.SetActive(false);
        PanelGameMode.SetActive(false);
        PanelStart.SetActive(false);
        PanelStore.SetActive(false);
        PanelBackpack.SetActive(false);
        PanelDefeat.SetActive(false);
        PanelVictory.SetActive(false);
        Paneltips.SetActive(false);
        Paneldevelop.SetActive(false);
    }
    //返回上级菜单
    public void ReturnPrevPanel()
    {
        PanelTD.SetActive(false);
        PanelSettings.SetActive(false);
        PanelPause.SetActive(false);
        PanelArchive.SetActive(false);
        PanelCheckPoint.SetActive(false);
        PanelGameMode.SetActive(false);
        PanelStart.SetActive(false );
        PanelStore.SetActive(false);
        PanelBackpack.SetActive(false);
        Paneldevelop.SetActive(false);
        switch (prevpanel )
        {
            case PrevPanel.PanelStart:PanelStart.SetActive(true);break;
            case PrevPanel.PanelPause:PanelPause.SetActive(true);break;
            default:break;
        }
    }
    public void returnToMainMenu()
    {
        prescene = 10;
        ChangeScene("mainmenu");
        PanelStart.SetActive(true);
    }
    public void StartTodevelop()
    {
        prevpanel = PrevPanel.PanelStart;
        Paneldevelop.SetActive(true);
        PanelStart.SetActive(false);
    }
   

    //从开始界面到背包界面
    public void StartToBackpack()
    {
        PanelBackpack.SetActive(true);
        PanelStart.SetActive(false);
        BPBoom.text = "X" + PLAYERINF.GetComponent<PlayerInf>().AB_count.ToString();
        Diamond_text.text = PLAYERINF.GetComponent<PlayerInf>().Diamond.ToString();
    }
    //从开始界面到防御塔列表
    public void StartToTD()
    {
       
        prevpanel = PrevPanel.PanelStart;

        TDSTORE.GetComponent<TDStore>().TD_count = 0;
        TDSTORE.GetComponent<TDStore>().PanelInit();
        PanelTD.SetActive(true);
        PanelStart.SetActive(false);
    }
    //从防御塔列表返回开始界面
    public void TDToStart()
    {
        PanelStart.SetActive(true);
        PanelTD.SetActive(false);
    }
   
        //从开始界面到商店界面
    public void StartToStore()
    {
        prevpanel = PrevPanel.PanelStart;
        ST_count = 0;
        STORE.GetComponent<Store>().Init();
        // STPrev_Btn.gameObject.SetActive(false);
        //STNext_Btn.gameObject.SetActive(true);
        PanelStart.SetActive(false);
        PanelStore.SetActive(true);
        
    }
    
   /* public void STNext()
    {
        ST_count++;
        if (ST_count > 6)
            ST_count = 6;
        if (ST_count > 0 && ST_count <= 6)
            STPrev_Btn.gameObject.SetActive(true);
        if (ST_count == 6)
            STNext_Btn.gameObject.SetActive(false);
        STDisplay();
    }*/
   /* public void STPrev()
    {

        ST_count--;
        if (ST_count < 0)
            ST_count = 0;
        if (ST_count == 0)
            STPrev_Btn.gameObject.SetActive(false);
        STDisplay();
    }*/
   /* public void STDisplay()
    {
        ST_text.color = Color.white;
        switch (ST_count)
        {
            case 0: ST_text.text = "0号商品"; break;
            case 1: ST_text.text = "1号商品"; break;
            case 2: ST_text.text = "2号商品"; break;
            case 3: ST_text.text = "3号商品"; break;
            case 4: ST_text.text = "4号商品"; break;
            case 5: ST_text.text = "5号商品"; break;
            case 6: ST_text.text = "6号商品"; break;
            default: break;
        }
    }*/
    //开始界面到设置界面
    public void StartToSettings()
    {
        prevpanel = PrevPanel.PanelStart;
        PanelStart.SetActive(false);
        PanelSettings.SetActive(true);
    }
    public void SettingToStart()
    {

    }
    //设置界面返回上级界面
    public void SettingsToStart()
    {
        if (prevpanel == PrevPanel.PanelStart)
        {
            PanelSettings.SetActive(false);
            PanelStart.SetActive(true);
            prevpanel = PrevPanel.PanelPause;
            prescene = 10;
        }
        else
        {
            ChangeScene("gamescene");
        }
        PanelSettings.SetActive(false);
    }

    
    //开始界面到游戏模式选择界面
    public void StartToGameMode()
    {
        PanelGameMode.SetActive(true);
        PanelCheckPoint.SetActive(false);
        PanelStart.SetActive(false);
        PanelSettings.SetActive(false);
    }
    //游戏模式选择界面到开始界面
    public void GameModeToStart()
    {
        PanelStart.SetActive(true);
        PanelGameMode.SetActive(false);
    }
    //游戏模式选择界面到关卡选择界面
    public  void GameModeToCheckPoint()
    {
        PanelCheckPoint.SetActive(true);
        PanelGameMode.SetActive(false);
    }
    //从关卡选择到模式选择
    public  void CheckPointToGameMode()
    {
        PanelGameMode.SetActive(true);
        PanelCheckPoint.SetActive(false);
    }


    //开始界面到存档管理界面
    public void StartToArchive()
    {
        PanelArchive.SetActive(true);
        PanelStart.SetActive(false);
    }
    //从存档界面到开始界面
    public void ArchiveToStart()
    {
        PanelArchive.SetActive(false);
        PanelStart.SetActive(true);
    }

    //进入暂停菜单
    public void Pause()
    {
        PanelPause.SetActive(true);
    }
    //从暂停菜单到主菜单
    public  void  PauseToStart()
    {
        prescene = 0;
        ChangeScene("mainmenu");
        //TIPS.GetComponent<Tips>().YESandNO_Tips();
        PanelStart.SetActive(true);
        PanelPause.SetActive(false);
    }

    //从暂停菜单到游戏设置页面
    public void PauseToGameSettings()
    {
        prescene = 20;
        ChangeScene("mainmenu");
        PanelInit();
        //PanelSettings.SetActive(true);
    }
   
    //进入结算，true为胜利，false为失败,score 为所得分数
    public void Settlement(bool state,int score)
    {
        prevpanel = PrevPanel.PanelStart;
        if(state)
        {
            PanelVictory.SetActive(true);
            Victory(score);
        }
        else
        {
            PanelDefeat.SetActive(true);
            Defeat(score);
        }
    }
    public void Victory(int score)
    {
        int diamond;
        diamond = score;
        PLAYERINF.GetComponent<PlayerInf>().CHDiamond(diamond);
        VicScore_te.text = score.ToString();
        VicReward_te.text = diamond.ToString();
    }
    public void Defeat(int score)
    {
        int diamond;
        diamond = score;
        PLAYERINF.GetComponent<PlayerInf>().CHDiamond(diamond);
        DefScore_te.text = score.ToString();
        DefReward_te.text = diamond.ToString();
    }

    
    //退出
    public void quit()
    {
        Application.Quit();
    }
    public void ChangeScene(string scenename)
    {
        //SceneManager.LoadSceneAsync(1);
        SceneManager.LoadScene(scenename);
        Debug.Log("changeScene");
    }
}
