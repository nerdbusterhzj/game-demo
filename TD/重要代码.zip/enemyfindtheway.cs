﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class enemyfindtheway : MonoBehaviour
{
    private Transform mtr;
    public static Transform FP;
    private NavMeshAgent nvAgent;
    // Start is called before the first frame update
    void Start()
    {
        mtr = this.gameObject.GetComponent<Transform>();
        FP = GameObject.FindGameObjectWithTag("Final Point").GetComponent<Transform>();
        nvAgent = this.gameObject.GetComponent<NavMeshAgent>();
        nvAgent.destination = FP.position;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
