﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;

public class enemyspawn : MonoBehaviour
{
    //敌人寻路起点
    public GameObject startpoint;
    //敌人预制件
    public GameObject Enemy;
    public GameObject Enemy1;
    public GameObject Enemy2;
    public GameObject Enemy3;
    public GameObject Enemy4;
    //Xml文件
    public TextAsset ConfigFile;
    public TextAsset ConfigFile1;
    public TextAsset ConfigFile2;
    public TextAsset ConfigFile3;

    //存放敌人的数组
    private List<spawndata> mEnemyDatas;

    //当前敌人进攻波数
    public int mWave = 0;
    //当前敌人索引
    private int mIndex = 0;
    //当前等待的时间
    private float mWait;


    // Start is called before the first frame update
    void Start()
    {
        //读取Xml数据
        ReadXml();
        //初始化攻击波数
        spawndata mData = mEnemyDatas[mIndex];//读取第一号敌人信息
        //设置攻击波数和等待时间
        mWave = mData.wave;
        mWait = mData.wait;
        //gamemanager.Instance.atkwave = mWave;
        //生成第一个敌人
        Createenemy(mData);
        mIndex += 1;
        //Debug.Log("mIndex:"+mIndex);
    }
    void Createenemy(spawndata mData)
    {
        if( (float)mData.level <=3)
        {
            Enemy = Enemy1;
        }
        else if((float)mData.level >3&& (float)mData.level<=6)
        {
            Enemy = Enemy2;
        }
        else if((float)mData.level > 6)
        {
            Enemy = Enemy3;
        }
        else Enemy = Enemy4;
        GameObject go = (GameObject)Instantiate(Enemy, startpoint.transform.position, Quaternion.identity);
        enemy _Enemy = go.GetComponent<enemy>();
        //根据Level计算敌人的生命值和移动速度
        _Enemy.max_hp = (float)mData.level * 5;
        _Enemy.hp = (float)mData.level * 5;
        _Enemy.level = (int)mData.level;
        //go.GetComponent<Enemy>().MoveSpeed = (float)mData.level * 0.15F;
        //go.GetComponent<Enemy>().StartNode = SpawnPath;
    }

    // Update is called once per frame
    void Update()
    {
        gamemanager.atkwave = mWave;
        if (mIndex <= mEnemyDatas.Count - 1)//敌人没有耗尽
        {
            //Debug.Log("fuck");
            spawnenemy();
        }
        else
        {
            //当索引数目大于敌人列表中的数目时，表示所有敌人以及生成完毕，此时
            if (mWave> 1&&gamemanager.hp>0)
            {
                gamemanager.Instance.IsWin = true;
                Debug.Log("玩家胜");
            }
        }
    }
    private void spawnenemy()
    {
        //取得下一个生成的敌人的数据
        spawndata mData = mEnemyDatas[mIndex];
        //开始计时
        mWait -= Time.deltaTime;
        if (mWait <= 0)
        {
            //如果当前是同一波敌人，则继续生成敌人
            if (mWave == mData.wave)
            {
                //设置等待时间
                mWait = mEnemyDatas[mIndex].wait;
                //设置进攻波数
                mWave = mEnemyDatas[mIndex].wave;
               // gamemanager.Instance.atkwave = mWave;
                //生成一个敌人
                
                
                Createenemy(mData);
                
                mIndex += 1;
            }//如果是下一波敌人，则需要等待这一波敌人全部死亡后再生成
            else if (mWave < mData.wave && gamemanager.Instance.Enemys.Count == 1)
            {
                Debug.Log("next wave");
                //设置等待时间
                mWait = mData.wait;
                //设置进攻波数
                mWave = mData.wave;
                //gamemanager.Instance.atkwave = mWave;
                //生成一个敌人
                Createenemy(mData);
                mIndex += 1;
            }
        }
    }
    //解析Xml文件
    void ReadXml()
    {
        if(gamestart.xmlflag==1)
        {
            ConfigFile = ConfigFile1;
        }
        else if(gamestart.xmlflag==2)
        {
            ConfigFile = ConfigFile2;
        }
        else if(gamestart.xmlflag==3)
        {
            ConfigFile = ConfigFile3;
        }

        //创建一个字典以存储敌人列表
        mEnemyDatas = new List<spawndata>();
        //加载Xml文档
        XmlDocument mDocument = new XmlDocument();
        mDocument.LoadXml(ConfigFile.text);
        XmlElement mRoot = mDocument.DocumentElement;
        //解析Xml文档
        XmlNodeList mNodes = mRoot.SelectNodes("/Enemies/Enemy");
        foreach (XmlNode mNode in mNodes)
        {
            //为每一个SpawnData赋值
            spawndata mData = new spawndata();
            mData.wave = int.Parse(mNode.Attributes[0].Value);
            mData.enemyname = mNode.Attributes[1].Value;
            mData.level = int.Parse(mNode.Attributes[2].Value);
            mData.wait = float.Parse(mNode.Attributes[3].Value);
            mEnemyDatas.Add(mData);
        }
    }

}
