﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mpanelctrl : MonoBehaviour
{
    CanvasGroup mpanel;

    // Start is called before the first frame update
    void Start()
    {
        mpanel = GetComponent<CanvasGroup>();
    }

    // Update is called once per frame
    void Update()
    {
        if (panelctrl.moneyout)
        {
            mpanel.alpha = 1;
            mpanel.blocksRaycasts = true;
            mpanel.interactable = true;
        }
        else
        {
            mpanel.alpha = 0;
            mpanel.blocksRaycasts = false;
            mpanel.interactable = false;
        }
    }
}
