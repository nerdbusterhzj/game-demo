﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class Firectrl : MonoBehaviour
{
    public GameObject gunbullet;
    public Transform firepos;
    public GameObject fireeffect;
    public AudioClip firesfx;
    private AudioSource source = null;

    public float atktime = 2.5f;//攻击间隔
    public float mtime = 0;

    // Start is called before the first frame update
    void Start()
    {
        source = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        fire();
    }
    void fire()
    {
        if (towerctrl.e_target == null)
        {
            Debug.Log("no");
            return;
        }
        mtime -= Time.deltaTime;
        if(mtime<0)
        {
            createbullet();
            source.PlayOneShot(firesfx, 1.0f);
            mtime = atktime;
        }
    }
    void createbullet()
    {
        Instantiate(gunbullet, firepos.position, firepos.rotation);
        GameObject spark = (GameObject)Instantiate(fireeffect, firepos.position, Quaternion.identity);
        Destroy(spark, spark.GetComponent<ParticleSystem>().main.duration);

    }
}
