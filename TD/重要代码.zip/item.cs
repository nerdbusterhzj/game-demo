﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class item : MonoBehaviour
{
    public Button boombutton;
    Text text;
    // Start is called before the first frame update
    void Start()
    {
        boombutton = GameObject.Find("Canvas/itemPanel/boom").GetComponent<Button>();
        boombutton.onClick.AddListener(boom);
        text = GameObject.Find("Canvas/itemPanel/boomnum").GetComponent<Text>();
        text.text = PlayerInf.AB_num.ToString();

    }

    // Update is called once per frame
    void Update()
    {
       
        text.text = PlayerInf.AB_num.ToString();
    }
    void boom()
    {
        if (PlayerInf.AB_num> 0)
        {
            
            PlayerInf.AB_num--;
            GameObject[] enemys = GameObject.FindGameObjectsWithTag("Enemy");
            int len = enemys.Length;
            for (int i = 0; i < len; i++)
            {
                enemy _enemy = enemys[i].GetComponent<enemy>();
                _enemy.setdamage(10000);
            }
            Debug.Log("done");
        }
        else return;
    }
}
