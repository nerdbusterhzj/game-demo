﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;


public class Archive : MonoBehaviour
{
    public GameObject PLAYERINF;
    public GameObject InputPanel;
    public InputField savename;
    public Button ArchiveBank_1_btn;//输出存档名
    public Text ArchiveBank_1;//输出存档名
    public Button creat_1_btn;
    public Button Save_1_btn;
    public Button dele_1_btn;

    public Button ArchiveBank_2_btn;
    public Text ArchiveBank_2;
    public Button creat_2_btn;
    public Button Save_2_btn;
    public Button dele_2_btn;

    public Button ArchiveBank_3_btn;
    public Text ArchiveBank_3;
    public Button creat_3_btn;
    public Button Save_3_btn;
    public Button dele_3_btn;

    public int inp = 0;
    public int ArchiveBankState_1;
    public int ArchiveBankState_2;

    LinkedList<string> file = new LinkedList<string>();
    LinkedListNode<string> file1 = new LinkedListNode<string>("");//用于存储存档_1名
    LinkedListNode<string> file2 = new LinkedListNode<string>("");//用于存储存档_2名
    LinkedListNode<string> file3 = new LinkedListNode<string>("");//用于存储存档_3名

    string filepath;

    // Start is called before the first frame update
    void Start()
    {
        filepath = Application.dataPath + "/Archives/";
        file.AddFirst(file1);
        file.AddAfter(file1, file2);
        file.AddAfter(file2, file3);
    }
    //写入存档信息
    public string WriteArchive()
    {
        PlayerInf playerinf = (PlayerInf)PLAYERINF.GetComponent("PlayerInf");
        return playerinf.GetInfString();
    }
    // Update is called once per frame
    void Update()
    {

    }
    void Init()
    {
        InputPanel.SetActive(false);
        creat_1_btn.gameObject.SetActive(false);
        Save_1_btn.gameObject.SetActive(false);
        dele_1_btn.gameObject.SetActive(false);

        creat_2_btn.gameObject.SetActive(false);
        Save_2_btn.gameObject.SetActive(false);
        dele_2_btn.gameObject.SetActive(false);

        creat_3_btn.gameObject.SetActive(false);
        Save_3_btn.gameObject.SetActive(false);
        dele_3_btn.gameObject.SetActive(false);
    }
    //查找所有存档
    public void ListArchive()
    {
        Init();
        Debug.Log("查找存档");

        // string str = "G:/unityproject/New Unity Project/Assets/Archives/";
        string[] file_1 = Directory.GetFiles(filepath, "*存档_1.txt", SearchOption.AllDirectories);//遍历文件搜索一号位存档
        if (file_1.Length == 0)
        {
            ArchiveBank_1.text = "空";
            creat_1_btn.gameObject.SetActive(true);
            //InputPanel.SetActive(true);
        }
        else
        {

            file1.Value = filename(file_1[0].Substring(filepath.Length));
            ArchiveBank_1.text = file1.Value;
            Debug.Log(file1.Value);
            Save_1_btn.gameObject.SetActive(true);
            dele_1_btn.gameObject.SetActive(true);

        }
        Debug.Log(Directory.GetFiles(filepath, "*存档_1.txt", SearchOption.AllDirectories));
        Debug.Log("filepath" + filepath);


        string[] file_2 = Directory.GetFiles(filepath, "*存档_2.txt", SearchOption.AllDirectories);
        if (file_2.Length == 0)
        {
            ArchiveBank_2.text = "空";
            creat_2_btn.gameObject.SetActive(true);
            //InputPanel.SetActive(true);
        }
        else
        {
            file2.Value = filename(file_2[0].Substring(filepath.Length));
            ArchiveBank_2.text = file2.Value;
            Debug.Log(file2.Value);
            Save_2_btn.gameObject.SetActive(true);
            dele_2_btn.gameObject.SetActive(true);
        }

        string[] file_3 = Directory.GetFiles(filepath, "*存档_3.txt", SearchOption.AllDirectories);
        if (file_3.Length == 0)
        {
            ArchiveBank_3.text = "空";
            creat_3_btn.gameObject.SetActive(true);
            //InputPanel.SetActive(true);
        }
        else
        {
            file3.Value = filename(file_3[0].Substring(filepath.Length));
            ArchiveBank_3.text = file3.Value;
            Debug.Log(file3.Value);
            Save_3_btn.gameObject.SetActive(true);
            dele_3_btn.gameObject.SetActive(true);
        }
        Debug.Log("path" + Application.dataPath);
        Debug.Log("查找存档完成");



    }
    public void creatfile()
    {
        if (inp == 1) ArchiveCreat_1();
        if (inp == 2) ArchiveCreat_2();
        if (inp == 3) ArchiveCreat_3();
        InputPanel.SetActive(false);
    }
    public void creat1()
    {
        inp = 1;
        InputFilename();

    }
    public void creat2()
    {
        inp = 2;
        InputFilename();

    }
    public void creat3()
    {
        inp = 3;
        InputFilename();

    }
    //呼出存档名输入框
    public void InputFilename()
    {
        InputPanel.SetActive(true);
        savename.text = "";
    }

    public void cancel()
    {
        savename.text = "";
        InputPanel.SetActive(false);
    }
    public string filename(string str)
    {
        string tem = "";
        tem = str.Substring(0, str.IndexOf("存"));
        for (int i = 0; i < str.Length; i++)
        {

        }
        return tem;
    }
    //在一号存档位上创建同名存档文件或者保存文档
    public void ArchiveCreat_1()
    {
        Debug.Log("创建文件1");
        Debug.Log("file1.Value=" + file1.Value);
        //string str = "G:/unityproject/New Unity Project/Assets/Archives";
        //string[] file_1 = Directory.GetFiles(filepath, "*存档_1.txt", SearchOption.AllDirectories);

        if (file1.Value == "")//如果当前栏位无存档,创建存档并写入信息
        {
            StreamWriter sw;
            FileInfo archive = new FileInfo(Application.dataPath + "/Archives" + "//" + savename.text + "存档_1.txt");
            if (!archive.Exists)
            {
                Debug.Log("创建文件2");
                sw = archive.CreateText();
                file1.Value = savename.text;
                ArchiveBank_1.text = file1.Value;
            }
            else
            {
                sw = archive.AppendText();
            }
            sw.WriteLine(WriteArchive());
            sw.Close();
            sw.Dispose();
        }
        else
        {
            Debug.Log("删除一号位旧文件" + filepath + file1.Value + "存档_1.txt");
            File.Delete(filepath + file1.Value + "存档_1.txt");
            StreamWriter sw;
            FileInfo archive = new FileInfo(Application.dataPath + "/Archives" + "//" + file1.Value + "存档_1.txt");
            if (!archive.Exists)
            {
                Debug.Log("创建文件-2");
                sw = archive.CreateText();
                ArchiveBank_1.text = file1.Value;
            }
            else
            {
                sw = archive.AppendText();
            }
            sw.WriteLine(WriteArchive());
            sw.Close();
            sw.Dispose();
        }
        ListArchive();
    }
    //删除1号位存档
    public void delete_1()
    {
        if (file1.Value != null)
        {
            Debug.Log("删除一号位旧文件" + filepath + file1.Value + "存档_1.txt");
            File.Delete(filepath + file1.Value + "存档_1.txt");
            file1.Value = "";
        }
        ArchiveBank_1.text = file1.Value;
        ListArchive();
    }
    //读取一号位存档
    public void ReadArchiveBank_1()
    {
        string path = Application.dataPath + "/Archives" + "//" + file1.Value + "存档_1.txt";
        StreamReader sr;
        string s;
        if (file1.Value != "")
        {
            sr = File.OpenText(path);
            s = sr.ReadLine();
            ;
            string[] arr = s.Split(new char[] { ' ' });
            Debug.Log(arr[0] + " " + arr[1] + " " + arr[7]);
            PLAYERINF.GetComponent<PlayerInf>().Point = StringToInt(arr[0]);
            PLAYERINF.GetComponent<PlayerInf>().difficulity = readdifficulity(arr[1]);
            PLAYERINF.GetComponent<PlayerInf>().setdiamond(StringToInt(arr[2]));
            PLAYERINF.GetComponent<PlayerInf>().setgoodsnum(Goods.SonicBomb, StringToInt(arr[3]));
            PLAYERINF.GetComponent<PlayerInf>().setgoodsnum(Goods.AntimatterBomb, StringToInt(arr[4]));
            PLAYERINF.GetComponent<PlayerInf>().setgoodsnum(Goods.TwoWayFoil, StringToInt(arr[5]));
            if (arr[6] == "True") PLAYERINF.GetComponent<PlayerInf>().CHTD(1);
            if (arr[7] == "True")
            {
                PLAYERINF.GetComponent<PlayerInf>().CHTD(2);
            }
            else
                PlayerInf.TD_2 = false;
            if (arr[8] == "True")
                PLAYERINF.GetComponent<PlayerInf>().CHTD(3);
            else
                PlayerInf.TD_3 = false;
            Debug.Log("读取存档完成");
        }
        else
            Debug.Log("无存档");

    }
    //在二号存档位上创建同名文件
    public void ArchiveCreat_2()
    {


        Debug.Log("创建文件3");
        Debug.Log("file2.Value=" + file2.Value);
        //string str = "G:/unityproject/New Unity Project/Assets/Archives";
        //string[] file_1 = Directory.GetFiles(filepath, "*存档_1.txt", SearchOption.AllDirectories);

        if (file2.Value == "")//如果当前栏位无存档,创建存档并写入信息
        {
            StreamWriter sw;
            FileInfo archive = new FileInfo(Application.dataPath + "/Archives" + "//" + savename.text + "存档_2.txt");
            if (!archive.Exists)
            {
                Debug.Log("创建文件4");
                sw = archive.CreateText();
                file2.Value = savename.text;
                ArchiveBank_2.text = file2.Value;
            }
            else
            {
                sw = archive.AppendText();
            }
            sw.WriteLine(WriteArchive());
            sw.Close();
            sw.Dispose();
        }
        else
        {
            Debug.Log("删除2号位旧文件" + filepath + file2.Value + "存档_2.txt");
            File.Delete(filepath + file2.Value + "存档_2.txt");
            StreamWriter sw;
            FileInfo archive = new FileInfo(Application.dataPath + "/Archives" + "//" + file2.Value + "存档_2.txt");
            if (!archive.Exists)
            {
                Debug.Log("创建文件-2");
                sw = archive.CreateText();
                ArchiveBank_2.text = file2.Value;
            }
            else
            {
                sw = archive.AppendText();
            }
            sw.WriteLine(WriteArchive());
            sw.Close();
            sw.Dispose();
        }
        ListArchive();
    }
    public void delete_2()
    {

        if (file2.Value != null)
        {
            Debug.Log("删除二号位旧文件" + filepath + file2.Value + "存档_2.txt");
            File.Delete(filepath + file2.Value + "存档_2.txt");
            file2.Value = "";
        }
        ArchiveBank_2.text = file2.Value;
        ListArchive();
    }
    //读取二号位存档
    public void ReadArchiveBank_2()
    {


        string path = Application.dataPath + "/Archives" + "//" + file2.Value + "存档_2.txt";
        StreamReader sr;
        string s;
        if (file2.Value != "")
        {
            sr = File.OpenText(path);
            s = sr.ReadLine();
            ;
            string[] arr = s.Split(new char[] { ' ' });
            Debug.Log(arr[0] + " " + arr[1] + " " + arr[7]);
            PLAYERINF.GetComponent<PlayerInf>().Point = StringToInt(arr[0]);
            PLAYERINF.GetComponent<PlayerInf>().difficulity = readdifficulity(arr[1]);
            PLAYERINF.GetComponent<PlayerInf>().setdiamond(StringToInt(arr[2]));
            PLAYERINF.GetComponent<PlayerInf>().setgoodsnum(Goods.SonicBomb, StringToInt(arr[3]));
            PLAYERINF.GetComponent<PlayerInf>().setgoodsnum(Goods.AntimatterBomb, StringToInt(arr[4]));
            PLAYERINF.GetComponent<PlayerInf>().setgoodsnum(Goods.TwoWayFoil, StringToInt(arr[5]));
            if (arr[6] == "True") PLAYERINF.GetComponent<PlayerInf>().CHTD(1);
            if (arr[7] == "True")
                PLAYERINF.GetComponent<PlayerInf>().CHTD(2);
            else
                PlayerInf.TD_2 = false;

            if (arr[8] == "True")
                PLAYERINF.GetComponent<PlayerInf>().CHTD(3);
            else
                PlayerInf.TD_3 = false;
            Debug.Log("读取存档完成");
        }
        else
            Debug.Log("无存档");
    }
    //在3号存档位上创建同名存档文件
    public void ArchiveCreat_3()
    {
        Debug.Log("创建文件5");
        Debug.Log("file3.Value=" + file3.Value);
        //string str = "G:/unityproject/New Unity Project/Assets/Archives";
        //string[] file_1 = Directory.GetFiles(filepath, "*存档_1.txt", SearchOption.AllDirectories);

        if (file3.Value == "")//如果当前栏位无存档,创建存档并写入信息
        {
            StreamWriter sw;
            FileInfo archive = new FileInfo(Application.dataPath + "/Archives" + "//" + savename.text + "存档_3.txt");
            if (!archive.Exists)
            {
                Debug.Log("创建文件6");
                sw = archive.CreateText();
                file3.Value = savename.text;
                ArchiveBank_3.text = file3.Value;
            }
            else
            {
                sw = archive.AppendText();
            }
            sw.WriteLine(WriteArchive());
            sw.Close();
            sw.Dispose();
        }
        else
        {
            Debug.Log("删除3号位旧文件" + filepath + file3.Value + "存档_3.txt");
            File.Delete(filepath + file3.Value + "存档_3.txt");
            StreamWriter sw;
            FileInfo archive = new FileInfo(Application.dataPath + "/Archives" + "//" + file3.Value + "存档_3.txt");
            if (!archive.Exists)
            {
                Debug.Log("创建文件-2-3");
                sw = archive.CreateText();
                ArchiveBank_3.text = file3.Value;
            }
            else
            {
                sw = archive.AppendText();
            }
            sw.WriteLine(WriteArchive());
            sw.Close();
            sw.Dispose();
        }
        ListArchive();
    }
    //删除3号位存档
    public void delete_3()
    {
        if (file3.Value != null)
        {
            Debug.Log("删除3号位旧文件" + filepath + file3.Value + "存档_3.txt");
            File.Delete(filepath + file3.Value + "存档_3.txt");
            file3.Value = "";
        }
        ArchiveBank_3.text = file3.Value;
        ListArchive();
    }
    //读取3号位存档
    public void ReadArchiveBank_3()
    {


        string path = Application.dataPath + "/Archives" + "//" + file3.Value + "存档_3.txt";
        StreamReader sr;
        string s;
        if (file3.Value != "")
        {
            sr = File.OpenText(path);
            s = sr.ReadLine();
            ;
            string[] arr = s.Split(new char[] { ' ' });
            Debug.Log(arr[0] + " " + arr[1] + " " + arr[7]);
            PLAYERINF.GetComponent<PlayerInf>().Point = StringToInt(arr[0]);
            PLAYERINF.GetComponent<PlayerInf>().difficulity = readdifficulity(arr[1]);
            PLAYERINF.GetComponent<PlayerInf>().setdiamond(StringToInt(arr[2]));
            PLAYERINF.GetComponent<PlayerInf>().setgoodsnum(Goods.SonicBomb, StringToInt(arr[3]));
            PLAYERINF.GetComponent<PlayerInf>().setgoodsnum(Goods.AntimatterBomb, StringToInt(arr[4]));
            PLAYERINF.GetComponent<PlayerInf>().setgoodsnum(Goods.TwoWayFoil, StringToInt(arr[5]));
            if (arr[6] == "True")
                PLAYERINF.GetComponent<PlayerInf>().CHTD(1);
            if (arr[7] == "True")
                PLAYERINF.GetComponent<PlayerInf>().CHTD(2);
            else
                PlayerInf.TD_2 = false;
            if (arr[8] == "True")
                PLAYERINF.GetComponent<PlayerInf>().CHTD(3);
            else
                PlayerInf.TD_3 = false;
            Debug.Log("读取存档完成");
        }
        else
            Debug.Log("无存档");
    }
    public Difficulity readdifficulity(string tem)
    {
        switch (tem)
        {
            case "Simple": return Difficulity.Simple;
            case "Normal": return Difficulity.Normal;
            case "Hard": return Difficulity.Hard;
            default: break;
        }
        return Difficulity.NULL;
    }
    public int StringToInt(string str)
    {
        int tem = 0;
        for (int i = str.Length - 1; i < str.Length && i >= 0; i--)
        {
            tem = tem + (str[i] - 48) * count(str.Length - 1 - i);
        }
        return tem;
    }
    public int count(int num)
    {
        int tem = 1;
        for (int i = 0; i < num; i++)
            tem = tem * 10;
        return tem;
    }
}

