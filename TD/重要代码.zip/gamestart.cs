﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class gamestart : MonoBehaviour
{
    public Button te_1_gamestartbutton;

    public static int xmlflag;

    // Start is called before the first frame update
    void Start()
    {
        te_1_gamestartbutton = GetComponent<Button>();
        te_1_gamestartbutton.onClick.AddListener(te1);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void te1()
    {
        if(this.gameObject.tag=="simple")
        {
            Debug.Log("s");
            xmlflag = 1;
        }
        else if(this.gameObject.tag=="normal")
        {
            Debug.Log("n");
            xmlflag = 2;
        }
        else if(this.gameObject.tag=="hard")
        {
            Debug.Log("h");
            xmlflag = 3;
        }
        Debug.Log("game start");
        SceneManager.LoadScene("gamescene");
    }
}
