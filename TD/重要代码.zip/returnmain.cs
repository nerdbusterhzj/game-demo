﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class returnmain : MonoBehaviour
{
    public Button return_main_button;
    // Start is called before the first frame update
    void Start()
    {
        return_main_button = GetComponent<Button>();
        return_main_button.onClick.AddListener(return_main);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void return_main()
    {
        pause.pauseflag = false;
        Time.timeScale = 1;
        gamemanager.atkwave = 0;
        gamemanager.fail = false;
        gamemanager.hp = gamemanager.Max_HP;
        gamemanager.money = 1000;
        gamemanager.socre = 0;
    }

}
