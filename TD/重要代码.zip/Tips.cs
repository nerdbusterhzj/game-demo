﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Tips : MonoBehaviour
{
    public GameObject Paneltips;
    public GameObject PanelStart;
    public GameObject PanelPause;
    public Button Yes_Btn;
    public Button NO_Btn;
    public Button Clo_Btn;
    public Text tips1;
    public Text tips2;
    public Text tips3;
    public int ti = 0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Debug.Log("ti=" + ti.ToString());
        if (ti == 1)
            Buytips();
        ti = 0;
    }
    public void TipsInin()
    {
        tips1.gameObject.SetActive(false);
        tips2.gameObject.SetActive(false);
        tips3.gameObject.SetActive(false);
        Yes_Btn.gameObject.SetActive(false);
        NO_Btn.gameObject.SetActive(false);
        Clo_Btn.gameObject.SetActive(false);
    }
    public void Buytips()
    {
        ti = 1;
        Debug.Log("TIP BUYtips");
        TipsInin();
        tips1.gameObject.SetActive(true);
        Clo_Btn.gameObject.SetActive(true);
        Paneltips.SetActive(true);
        
    }
    public void CLO_Btn()
    {
        Paneltips.SetActive(false);
    }
    public void YESandNO_Tips()
    {
        TipsInin();
        //ChangeScene("mainmenu");
        tips2.gameObject.SetActive(true);
        Yes_Btn.gameObject.SetActive(true);
        NO_Btn.gameObject.SetActive(true);
        Paneltips.SetActive(true);
    }
    public void YES_Btn()
    {
        Paneltips.SetActive(false);
        PanelPause.SetActive(false);
        //ChangeScene("mainmenu");
        PanelStart.SetActive(true);
    }
    public void ChangeScene(string scenename)
    {
        SceneManager.LoadScene(scenename);
    }
    public void No_Btn()
    {
        Paneltips.SetActive(false);
        ChangeScene("Pause");
    }



}
