﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tip : MonoBehaviour
{
    public GameObject PanelTip;
    // Start is called before the first frame update
    void Start()
    {
        
    }
    public void Artip()
    {
        PanelTip.SetActive(true);
    }
    public void clotip()
    {
        PanelTip.SetActive(false);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
