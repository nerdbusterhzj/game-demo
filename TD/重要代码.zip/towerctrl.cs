﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class towerctrl : MonoBehaviour
{
    public int towertype;//塔种类
    public float atkdist=20.0f;
    public float mdist=0;

    public Canvas tower;


   // private Transform target;

    public static enemy e_target;
   
    
    // Start is called before the first frame update
    void Start()
    {
        //target = GameObject.FindGameObjectWithTag("Enemy").GetComponent<Transform>();
        //e_target = target.GetComponent<enemy>();
        if(gameObject.tag=="tower1")
        {
            towertype = 1;
           
        }
        else if(gameObject.tag=="tower2")
        {
            atkdist = 30.0f;
            towertype = 2;
           
        }
        else if(gameObject.tag=="tower3")
        {
            towertype = 3;
        }
        tower = this.GetComponentInChildren<Canvas>();
        tower.gameObject.SetActive(false);

    }

    // Update is called once per frame
    void Update()
    {
        findenemy();
        //float dist = Vector3.Distance(target.position, transform.position);
        //Debug.Log(dist);
        //if(dist<=atkdist)
        // {
        //transform.LookAt(target);

        //}
        rotation();
        if(Input.GetMouseButtonDown(1))
        {
            tower.gameObject.SetActive(false);
        }
       
    }
    void findenemy()
    {
        e_target = null;
        ArrayList menemys = gamemanager.Instance.Enemys;
        foreach(enemy _enemy in menemys)
        {
            if(_enemy.hp<=0)
            {
                continue;
            }
            float dist = Vector3.Distance(_enemy.transform.position, transform.position);
            if(dist>atkdist)
            {
                Debug.Log("未进入攻击区域");
                
                //return;
            }
            else if(mdist>dist||mdist==0)
            {
                e_target = _enemy;
                mdist = dist;
                
            }
            

        }
        mdist = 0;

    }
    void rotation()
    {
        if(e_target==null)
        {
            return ;
        }
        transform.LookAt(e_target.transform.position);
    }
    private void OnMouseUp()
    {
        tower.gameObject.SetActive(true);
    }
    public void destroy()
    {
        Destroy(this.gameObject);
    }

}
