﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Goods
{
    SonicBomb,//次声波核弹
    AntimatterBomb,//反物质炸弹
    TwoWayFoil//二向箔
}
public enum Difficulity
{
    NULL,
    Simple,
    Normal,
    Hard
}
public class PlayerInf : MonoBehaviour
{
    public int Point;//最新关卡进度
    public Difficulity  difficulity;//最新关卡难度
    public int Diamond=350;//钻石
    public Goods goods;//玩家拥有道具
    public int SB_count;
    public int AB_count;
    public int TWF_count;
    public static bool TD_1 = true;
    public static bool TD_2 = false;
    public static bool TD_3 = false;
    

    public static int AB_num;
    public static int D_num=350;


    // Start is called before the first frame update
    void Start()
    {
        Init();
    }

    public void Init ()
    {
        //SB_count = 0;
        //AB_count = 0;
        //TWF_count = 0;
        //Diamond = 100;
        Diamond = D_num;
        AB_count = AB_num;
        Point = 1;
        difficulity = Difficulity.Simple;
    }
    public  string GetInfString()
    {
        
        string tem = "";
        tem = Point.ToString() + " " + difficulity.ToString() + " " + Diamond.ToString() + " " + SB_count.ToString() + " "
            + AB_count.ToString() + " " + TWF_count.ToString() + " " + TD_1.ToString() + " " + TD_2.ToString() + " " + TD_3.ToString(); ;
        return tem;
    }
    public bool TD(int num)
    {
        if (num == 2 && TD_2 == true)
            return true;
        if (num == 3 && TD_3 == true)
            return true;

        return false;
    }
    public void CHTD(int num)
    {
        if (num == 1) TD_1 = true;
        if (num == 2) TD_2 = true;
        if (num == 3) TD_3 = true;
    }
    public void CHGoodsCount(Goods goods ,int num)
    {
        switch (goods )
        {
            case Goods.SonicBomb:SB_count = SB_count+num; break;
            case Goods.AntimatterBomb:AB_count = AB_count+num;
                AB_num = AB_count;
                break;
            case Goods.TwoWayFoil:TWF_count = TWF_count+num;break;
            default:break;
        }
    }
    public void SetDifficulity(int num)
    {
        switch (num)
        {
            case 1:difficulity = Difficulity.Simple;break;
            case 2:difficulity = Difficulity.Normal;break;
            case 3:difficulity = Difficulity.Hard;break;
            default:break;
        }
    }
    public void SetPoint(int num)
    {
        Point = num;
    }
    public void CHDiamond(int num)
    {
        Diamond = Diamond+num;
        D_num = Diamond;
    }
    public void setgoodsnum(Goods goods, int num)
    {
        switch (goods)
        {
            case Goods.SonicBomb: SB_count = num; break;
            case Goods.AntimatterBomb: AB_count = num; break;
            case Goods.TwoWayFoil: TWF_count = num; break;
            default: break;
        }
    }
    public int getgoods_count(int num)
    {
        int tem = 0;
        if (num == 1) tem = SB_count;
        if (num == 2) tem = AB_count;
        if (num == 3) tem = TWF_count;

        return tem;
    }
    public int getdiamond()
    {
        return Diamond;
    }
    public void setdiamond(int num)
    {
        Diamond = num;
    }


    // Update is called once per frame
    void Update()
    {
        //AB_count = AB_num;
        //Diamond = D_num;
    }
}
